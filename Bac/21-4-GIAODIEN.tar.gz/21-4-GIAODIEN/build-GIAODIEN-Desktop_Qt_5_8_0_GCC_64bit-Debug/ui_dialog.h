/********************************************************************************
** Form generated from reading UI file 'dialog.ui'
**
** Created by: Qt User Interface Compiler version 5.8.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_DIALOG_H
#define UI_DIALOG_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QListWidget>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QStackedWidget>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_dialog
{
public:
    QWidget *centralWidget;
    QGridLayout *gridLayout;
    QStackedWidget *stackedWidget;
    QWidget *page;
    QGridLayout *gridLayout_2;
    QVBoxLayout *verticalLayout_7;
    QPushButton *pushButton_2;
    QPushButton *pushButton;
    QVBoxLayout *verticalLayout;
    QLabel *Digital_clock;
    QLabel *Digital_date;
    QHBoxLayout *horizontalLayout;
    QLabel *label_4;
    QHBoxLayout *horizontalLayout_7;
    QVBoxLayout *verticalLayout_8;
    QLabel *label_2;
    QSpacerItem *verticalSpacer;
    QHBoxLayout *horizontalLayout_4;
    QLabel *label_9;
    QVBoxLayout *verticalLayout_2;
    QPushButton *pushButton_4;
    QSpacerItem *verticalSpacer_2;
    QHBoxLayout *horizontalLayout_2;
    QLabel *txtnamepr;
    QHBoxLayout *horizontalLayout_5;
    QLabel *label_10;
    QLineEdit *txtuser;
    QHBoxLayout *horizontalLayout_6;
    QLabel *label_11;
    QLineEdit *txtpass;
    QWidget *page_2;
    QGridLayout *gridLayout_3;
    QHBoxLayout *horizontalLayout_8;
    QLabel *label_8;
    QVBoxLayout *verticalLayout_9;
    QPushButton *pushButton_5;
    QPushButton *pushButton_6;
    QVBoxLayout *verticalLayout_3;
    QLabel *label_3;
    QHBoxLayout *horizontalLayout_13;
    QPushButton *pushButton_3;
    QVBoxLayout *verticalLayout_4;
    QLabel *Digital_clock_2;
    QLabel *Digital_date_2;
    QHBoxLayout *horizontalLayout_3;
    QPushButton *pushButton_8;
    QPushButton *pushButton_7;
    QVBoxLayout *verticalLayout_5;
    QPushButton *pushButton_9;
    QListWidget *listWidget;
    QHBoxLayout *horizontalLayout_10;
    QLabel *label;
    QLineEdit *name_dataadd;
    QMenuBar *menuBar;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *dialog)
    {
        if (dialog->objectName().isEmpty())
            dialog->setObjectName(QStringLiteral("dialog"));
        dialog->resize(684, 523);
        centralWidget = new QWidget(dialog);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        gridLayout = new QGridLayout(centralWidget);
        gridLayout->setSpacing(6);
        gridLayout->setContentsMargins(11, 11, 11, 11);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        stackedWidget = new QStackedWidget(centralWidget);
        stackedWidget->setObjectName(QStringLiteral("stackedWidget"));
        stackedWidget->setStyleSheet(QStringLiteral("background-image: url(:/image/technology.jpg);"));
        page = new QWidget();
        page->setObjectName(QStringLiteral("page"));
        gridLayout_2 = new QGridLayout(page);
        gridLayout_2->setSpacing(6);
        gridLayout_2->setContentsMargins(11, 11, 11, 11);
        gridLayout_2->setObjectName(QStringLiteral("gridLayout_2"));
        verticalLayout_7 = new QVBoxLayout();
        verticalLayout_7->setSpacing(6);
        verticalLayout_7->setObjectName(QStringLiteral("verticalLayout_7"));
        pushButton_2 = new QPushButton(page);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));

        verticalLayout_7->addWidget(pushButton_2);

        pushButton = new QPushButton(page);
        pushButton->setObjectName(QStringLiteral("pushButton"));

        verticalLayout_7->addWidget(pushButton);


        gridLayout_2->addLayout(verticalLayout_7, 2, 3, 2, 1);

        verticalLayout = new QVBoxLayout();
        verticalLayout->setSpacing(6);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        Digital_clock = new QLabel(page);
        Digital_clock->setObjectName(QStringLiteral("Digital_clock"));

        verticalLayout->addWidget(Digital_clock);

        Digital_date = new QLabel(page);
        Digital_date->setObjectName(QStringLiteral("Digital_date"));

        verticalLayout->addWidget(Digital_date);


        gridLayout_2->addLayout(verticalLayout, 0, 3, 1, 1);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setSpacing(6);
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        label_4 = new QLabel(page);
        label_4->setObjectName(QStringLiteral("label_4"));
        label_4->setPixmap(QPixmap(QString::fromUtf8("../image/smfpt.png")));
        label_4->setScaledContents(true);

        horizontalLayout->addWidget(label_4);


        gridLayout_2->addLayout(horizontalLayout, 0, 0, 1, 1);

        horizontalLayout_7 = new QHBoxLayout();
        horizontalLayout_7->setSpacing(6);
        horizontalLayout_7->setObjectName(QStringLiteral("horizontalLayout_7"));
        verticalLayout_8 = new QVBoxLayout();
        verticalLayout_8->setSpacing(6);
        verticalLayout_8->setObjectName(QStringLiteral("verticalLayout_8"));
        label_2 = new QLabel(page);
        label_2->setObjectName(QStringLiteral("label_2"));

        verticalLayout_8->addWidget(label_2);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_8->addItem(verticalSpacer);


        horizontalLayout_7->addLayout(verticalLayout_8);


        gridLayout_2->addLayout(horizontalLayout_7, 4, 0, 1, 3);

        horizontalLayout_4 = new QHBoxLayout();
        horizontalLayout_4->setSpacing(6);
        horizontalLayout_4->setObjectName(QStringLiteral("horizontalLayout_4"));
        label_9 = new QLabel(page);
        label_9->setObjectName(QStringLiteral("label_9"));

        horizontalLayout_4->addWidget(label_9);


        gridLayout_2->addLayout(horizontalLayout_4, 1, 0, 1, 4);

        verticalLayout_2 = new QVBoxLayout();
        verticalLayout_2->setSpacing(6);
        verticalLayout_2->setObjectName(QStringLiteral("verticalLayout_2"));
        pushButton_4 = new QPushButton(page);
        pushButton_4->setObjectName(QStringLiteral("pushButton_4"));

        verticalLayout_2->addWidget(pushButton_4);

        verticalSpacer_2 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_2->addItem(verticalSpacer_2);


        gridLayout_2->addLayout(verticalLayout_2, 4, 3, 1, 1);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setSpacing(6);
        horizontalLayout_2->setObjectName(QStringLiteral("horizontalLayout_2"));
        txtnamepr = new QLabel(page);
        txtnamepr->setObjectName(QStringLiteral("txtnamepr"));
        txtnamepr->setMaximumSize(QSize(316, 16777215));

        horizontalLayout_2->addWidget(txtnamepr);


        gridLayout_2->addLayout(horizontalLayout_2, 0, 1, 1, 2);

        horizontalLayout_5 = new QHBoxLayout();
        horizontalLayout_5->setSpacing(6);
        horizontalLayout_5->setObjectName(QStringLiteral("horizontalLayout_5"));
        label_10 = new QLabel(page);
        label_10->setObjectName(QStringLiteral("label_10"));

        horizontalLayout_5->addWidget(label_10);

        txtuser = new QLineEdit(page);
        txtuser->setObjectName(QStringLiteral("txtuser"));

        horizontalLayout_5->addWidget(txtuser);


        gridLayout_2->addLayout(horizontalLayout_5, 2, 0, 1, 3);

        horizontalLayout_6 = new QHBoxLayout();
        horizontalLayout_6->setSpacing(6);
        horizontalLayout_6->setObjectName(QStringLiteral("horizontalLayout_6"));
        label_11 = new QLabel(page);
        label_11->setObjectName(QStringLiteral("label_11"));

        horizontalLayout_6->addWidget(label_11);

        txtpass = new QLineEdit(page);
        txtpass->setObjectName(QStringLiteral("txtpass"));
        txtpass->setEchoMode(QLineEdit::Password);

        horizontalLayout_6->addWidget(txtpass);


        gridLayout_2->addLayout(horizontalLayout_6, 3, 0, 1, 3);

        stackedWidget->addWidget(page);
        page_2 = new QWidget();
        page_2->setObjectName(QStringLiteral("page_2"));
        gridLayout_3 = new QGridLayout(page_2);
        gridLayout_3->setSpacing(6);
        gridLayout_3->setContentsMargins(11, 11, 11, 11);
        gridLayout_3->setObjectName(QStringLiteral("gridLayout_3"));
        horizontalLayout_8 = new QHBoxLayout();
        horizontalLayout_8->setSpacing(6);
        horizontalLayout_8->setObjectName(QStringLiteral("horizontalLayout_8"));
        label_8 = new QLabel(page_2);
        label_8->setObjectName(QStringLiteral("label_8"));

        horizontalLayout_8->addWidget(label_8);


        gridLayout_3->addLayout(horizontalLayout_8, 0, 1, 1, 2);

        verticalLayout_9 = new QVBoxLayout();
        verticalLayout_9->setSpacing(6);
        verticalLayout_9->setObjectName(QStringLiteral("verticalLayout_9"));
        pushButton_5 = new QPushButton(page_2);
        pushButton_5->setObjectName(QStringLiteral("pushButton_5"));

        verticalLayout_9->addWidget(pushButton_5);

        pushButton_6 = new QPushButton(page_2);
        pushButton_6->setObjectName(QStringLiteral("pushButton_6"));

        verticalLayout_9->addWidget(pushButton_6);


        gridLayout_3->addLayout(verticalLayout_9, 3, 0, 1, 1);

        verticalLayout_3 = new QVBoxLayout();
        verticalLayout_3->setSpacing(6);
        verticalLayout_3->setObjectName(QStringLiteral("verticalLayout_3"));
        label_3 = new QLabel(page_2);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setPixmap(QPixmap(QString::fromUtf8("../image/smfpt.png")));
        label_3->setScaledContents(true);

        verticalLayout_3->addWidget(label_3);


        gridLayout_3->addLayout(verticalLayout_3, 0, 0, 1, 1);

        horizontalLayout_13 = new QHBoxLayout();
        horizontalLayout_13->setSpacing(6);
        horizontalLayout_13->setObjectName(QStringLiteral("horizontalLayout_13"));
        pushButton_3 = new QPushButton(page_2);
        pushButton_3->setObjectName(QStringLiteral("pushButton_3"));

        horizontalLayout_13->addWidget(pushButton_3);


        gridLayout_3->addLayout(horizontalLayout_13, 4, 0, 1, 1);

        verticalLayout_4 = new QVBoxLayout();
        verticalLayout_4->setSpacing(6);
        verticalLayout_4->setObjectName(QStringLiteral("verticalLayout_4"));
        Digital_clock_2 = new QLabel(page_2);
        Digital_clock_2->setObjectName(QStringLiteral("Digital_clock_2"));

        verticalLayout_4->addWidget(Digital_clock_2);

        Digital_date_2 = new QLabel(page_2);
        Digital_date_2->setObjectName(QStringLiteral("Digital_date_2"));

        verticalLayout_4->addWidget(Digital_date_2);


        gridLayout_3->addLayout(verticalLayout_4, 0, 3, 1, 1);

        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setSpacing(6);
        horizontalLayout_3->setObjectName(QStringLiteral("horizontalLayout_3"));
        pushButton_8 = new QPushButton(page_2);
        pushButton_8->setObjectName(QStringLiteral("pushButton_8"));

        horizontalLayout_3->addWidget(pushButton_8);

        pushButton_7 = new QPushButton(page_2);
        pushButton_7->setObjectName(QStringLiteral("pushButton_7"));

        horizontalLayout_3->addWidget(pushButton_7);


        gridLayout_3->addLayout(horizontalLayout_3, 4, 2, 1, 2);

        verticalLayout_5 = new QVBoxLayout();
        verticalLayout_5->setSpacing(6);
        verticalLayout_5->setObjectName(QStringLiteral("verticalLayout_5"));
        pushButton_9 = new QPushButton(page_2);
        pushButton_9->setObjectName(QStringLiteral("pushButton_9"));

        verticalLayout_5->addWidget(pushButton_9);


        gridLayout_3->addLayout(verticalLayout_5, 4, 1, 1, 1);

        listWidget = new QListWidget(page_2);
        listWidget->setObjectName(QStringLiteral("listWidget"));

        gridLayout_3->addWidget(listWidget, 3, 1, 1, 3);

        horizontalLayout_10 = new QHBoxLayout();
        horizontalLayout_10->setSpacing(6);
        horizontalLayout_10->setObjectName(QStringLiteral("horizontalLayout_10"));
        label = new QLabel(page_2);
        label->setObjectName(QStringLiteral("label"));

        horizontalLayout_10->addWidget(label);


        gridLayout_3->addLayout(horizontalLayout_10, 1, 0, 1, 1);

        name_dataadd = new QLineEdit(page_2);
        name_dataadd->setObjectName(QStringLiteral("name_dataadd"));

        gridLayout_3->addWidget(name_dataadd, 1, 1, 1, 2);

        stackedWidget->addWidget(page_2);

        gridLayout->addWidget(stackedWidget, 0, 0, 1, 1);

        dialog->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(dialog);
        menuBar->setObjectName(QStringLiteral("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 684, 22));
        dialog->setMenuBar(menuBar);
        mainToolBar = new QToolBar(dialog);
        mainToolBar->setObjectName(QStringLiteral("mainToolBar"));
        dialog->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(dialog);
        statusBar->setObjectName(QStringLiteral("statusBar"));
        dialog->setStatusBar(statusBar);

        retranslateUi(dialog);

        QMetaObject::connectSlotsByName(dialog);
    } // setupUi

    void retranslateUi(QMainWindow *dialog)
    {
        dialog->setWindowTitle(QApplication::translate("dialog", "dialog", Q_NULLPTR));
        pushButton_2->setText(QApplication::translate("dialog", "LOG IN", Q_NULLPTR));
        pushButton->setText(QApplication::translate("dialog", "PushButton", Q_NULLPTR));
        Digital_clock->setText(QApplication::translate("dialog", "Clock", Q_NULLPTR));
        Digital_date->setText(QApplication::translate("dialog", "Date", Q_NULLPTR));
        label_4->setText(QString());
        label_2->setText(QApplication::translate("dialog", "[+]Status", Q_NULLPTR));
        label_9->setText(QApplication::translate("dialog", "Sign in", Q_NULLPTR));
        pushButton_4->setText(QApplication::translate("dialog", "PushButton", Q_NULLPTR));
        txtnamepr->setText(QApplication::translate("dialog", "<html><head/><body><p align=\"center\"><span style=\" font-size:14pt; font-weight:600; color:#a40000;\">HOME MONITORING SYSTEM</span></p></body></html>", Q_NULLPTR));
        label_10->setText(QApplication::translate("dialog", "Username", Q_NULLPTR));
        label_11->setText(QApplication::translate("dialog", "Password", Q_NULLPTR));
        label_8->setText(QApplication::translate("dialog", "<html><head/><body><p align=\"center\"><span style=\" font-size:14pt; font-weight:600; color:#bf4040;\">HOME MONITORING SYSTEM</span></p></body></html>", Q_NULLPTR));
        pushButton_5->setText(QApplication::translate("dialog", "Register", Q_NULLPTR));
        pushButton_6->setText(QApplication::translate("dialog", "Control", Q_NULLPTR));
        label_3->setText(QString());
        pushButton_3->setText(QApplication::translate("dialog", "LOG OUT", Q_NULLPTR));
        Digital_clock_2->setText(QApplication::translate("dialog", "Clock", Q_NULLPTR));
        Digital_date_2->setText(QApplication::translate("dialog", "Date", Q_NULLPTR));
        pushButton_8->setText(QApplication::translate("dialog", "Turn On", Q_NULLPTR));
        pushButton_7->setText(QApplication::translate("dialog", "Turn Off", Q_NULLPTR));
        pushButton_9->setText(QApplication::translate("dialog", "Delete", Q_NULLPTR));
        label->setText(QApplication::translate("dialog", "Divice", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class dialog: public Ui_dialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DIALOG_H
