#include "dialog.h"
#include "ui_dialog.h"

#include <qcolor.h>
#include <QColor>

#include <QMainWindow>
#include <QMainWindow>
#include <QDialog>
#include <QDebug>
#include <QDate>
#include <string.h>
#include <QTime>
#include <QTimer>
#include <QTimeZone>
#include <QIntValidator>
#include <QPixmap>
#include <QListWidget>

dialog::dialog(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::dialog)
{
    ui->setupUi(this);
    //showTime();
    //showTime2();
    QTimer *timer=new QTimer(this);
    connect(timer,SIGNAL(timeout()),this,SLOT(showTime()));
    connect(timer,SIGNAL(timeout()),this,SLOT(showTime2()));
    timer->start();

//    QPixmap bkgnd("/home/bacle/Documents/WHATTHEF/EASY/image/technology.jpg");
//    bkgnd =bkgnd.scaled(this->size(),Qt::IgnoreAspectRatio);
//    QPalette palette;
//    palette.setBrush(QPalette::Background,bkgnd);
//    this->setPalette(palette);
}

dialog::~dialog()
{
    delete ui;
}

void dialog::on_pushButton_2_clicked()
{
    ui->stackedWidget ->setCurrentIndex(1);
    ui->label_2->setText("Button is clicked");
}

void dialog::on_pushButton_3_clicked()
{
    ui->stackedWidget ->setCurrentIndex(0);
}

void dialog::showTime()
{



    QTime time=QTime::currentTime();
    QString time_text=time.toString("HH:mm:ss");
    if((time.second()%2)==0)
        {
            time_text[2]=' ';
            time_text[5]=' ';
        }
    ui->Digital_clock->setText(time_text);


    QDate date=QDate::currentDate();
    QString dateString=date.toString("dd.MM.yyyy");
    ui->Digital_date->setText(dateString);

}

void dialog::showTime2()
{



    QTime time=QTime::currentTime();
    QString time_text=time.toString("HH:mm:ss");
    if((time.second()%2)==0)
        {
            time_text[2]=' ';
            time_text[5]=' ';
        }
    ui->Digital_clock_2->setText(time_text);


    QDate date=QDate::currentDate();
    QString dateString=date.toString("dd.MM.yyyy");
    ui->Digital_date_2->setText(dateString);
}
void dialog::on_pushButton_5_clicked()
{
    //for(int i=0;i<40;i++)

    //ui->listWidget->addItem("Device "+ QString::number(j));
    QString addmore;
    addmore = ui->name_dataadd->text();
    ui ->listWidget ->addItem(addmore);

}

void dialog::on_pushButton_8_clicked()
{
    //ui->listWidget->currentItem()->setText("This Device has been chose");

    QListWidgetItem *itm = ui->listWidget->currentItem();//->setText("Fuzzy");
    itm->setText("This Device has been chose");
    itm ->setTextColor(Qt::red);
}

void dialog::on_pushButton_9_clicked()
{
    delete ui->listWidget->currentItem();
}

void dialog::on_pushButton_6_clicked()
{
    QListWidgetItem*itm = ui->listWidget->currentItem();
        itm ->setTextColor(Qt::red);

}
