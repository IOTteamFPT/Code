#ifndef DIALOG_H
#define DIALOG_H

#include <qcolor.h>
#include <QColor>
#include <QMainWindow>
#include <QMainWindow>
#include <QDialog>
#include <QDebug>
#include <QDate>
#include <string.h>
#include <QTime>
#include <QTimer>
#include <QTimeZone>
#include <QIntValidator>
#include <QPixmap>
#include <QListWidget>

namespace Ui {
class dialog;
}

class dialog : public QMainWindow
{
    Q_OBJECT

public:
    explicit dialog(QWidget *parent = 0);
    ~dialog();

private slots:
    void on_pushButton_2_clicked();

    void on_pushButton_3_clicked();

    void showTime();
    void showTime2();

    void on_pushButton_5_clicked();

    void on_pushButton_8_clicked();

    void on_pushButton_9_clicked();

    void on_pushButton_6_clicked();

private:
    Ui::dialog *ui;
};

#endif // DIALOG_H
