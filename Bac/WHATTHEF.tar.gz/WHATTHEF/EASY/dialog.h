#ifndef DIALOG_H
#define DIALOG_H

#include <QMainWindow>
#include <QMainWindow>
#include <QDialog>
#include <QDebug>
#include <QDate>
#include <string.h>
#include <QTime>
#include <QTimer>
#include <QTimeZone>
#include <QtSerialPort/QSerialPortInfo>
#include <QIntValidator>

namespace Ui {
class dialog;
}

class dialog : public QMainWindow
{
    Q_OBJECT

public:
    explicit dialog(QWidget *parent = 0);
    ~dialog();

private slots:
    void on_pushButton_2_clicked();

    void on_pushButton_4_clicked();

    void showTime();
    void showTime2();

private:
    Ui::dialog *ui;
};

#endif // DIALOG_H
