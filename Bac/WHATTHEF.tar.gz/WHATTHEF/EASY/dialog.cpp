#include "dialog.h"
#include "ui_dialog.h"
#include <qcolor.h>
#include <QMainWindow>
#include <QMainWindow>
#include <QDialog>
#include <QDebug>
#include <QDate>
#include <string.h>
#include <QTime>
#include <QTimer>
#include <QTimeZone>
#include <QtSerialPort/QSerialPortInfo>
#include <QIntValidator>

dialog::dialog(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::dialog)
{
    ui->setupUi(this);
    showTime();
    showTime2();
    QTimer *timer=new QTimer(this);
    connect(timer,SIGNAL(timeout()),this,SLOT(showTime()));
    connect(timer,SIGNAL(timeout()),this,SLOT(showTime2()));
    timer->start();

    QPixmap bkgnd("/home/bacle/Documents/WHATTHEF/image/control.jpg");
    bkgnd =bkgnd.scaled(this->size(),Qt::IgnoreAspectRatio);
    QPalette palette;
    palette.setBrush(QPalette::Background,bkgnd);
    this->setPalette(palette);

}

dialog::~dialog()
{
    delete ui;
}

void dialog::on_pushButton_2_clicked()
{
       //color:white;
    ui->stackedWidget ->setCurrentIndex(2);
}

void dialog::on_pushButton_4_clicked()
{
    ui->stackedWidget ->setCurrentIndex(1);
}

void dialog::showTime()
{



    QTime time=QTime::currentTime();
    QString time_text=time.toString("HH:mm:ss");
    if((time.second()%2)==0)
        {
            time_text[2]=' ';
            time_text[5]=' ';
        }
    ui->Digital_clock->setText(time_text);


    QDate date=QDate::currentDate();
    QString dateString=date.toString("dd.MM.yyyy");
    ui->Digital_date->setText(dateString);

}

void dialog::showTime2()
{



    QTime time=QTime::currentTime();
    QString time_text=time.toString("HH:mm:ss");
    if((time.second()%2)==0)
        {
            time_text[2]=' ';
            time_text[5]=' ';
        }
    ui->Digital_clock_2->setText(time_text);


    QDate date=QDate::currentDate();
    QString dateString=date.toString("dd.MM.yyyy");
    ui->Digital_date_2->setText(dateString);

}
