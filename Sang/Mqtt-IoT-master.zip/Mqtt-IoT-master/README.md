# Mqtt-IoT

###Installing & Running
To install and run simply follow these steps:

1)  Clone this repo

2)  Open your terminal and run `npm install ` && ` node server.js`

3)  Your server is now available at `http://localhost:3000/`


