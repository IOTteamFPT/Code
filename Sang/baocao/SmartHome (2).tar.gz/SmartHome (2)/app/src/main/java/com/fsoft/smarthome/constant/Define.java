package com.fsoft.smarthome.constant;

/**
 * Created by HoangBVN on 5/9/2017.
 */

public class Define {
    public static final String TAG = "MQTT";

    public static final String APP_ID = "org.mosquitto.android.mqtt";

    public static final String MQTT_BROKER = "192.168.43.129";
    public static final String MQTT_PORT = "1883";
    public static final String MQTT_URL = "tcp://" + MQTT_BROKER + ":" + MQTT_PORT;
    public static final String MQTT_TOPIC = "house/register/user";
    public static final String TOPIC_USER_REG = "house/register/user";
    public static final String TOPIC_LED = "app/digital_device";
    public static final String TOPIC_HOUSE_GET = "house/get/user";
    public static final String TOPIC_HOUSE_ADD = "house/add/house";
    public static final String TOPIC_HOUSE_REG = "house/register/house";
    public static final String TOPIC_HOME_GET = "house/get/house";

    public static final String MQTT_MSG_RECEIVED_INTENT = "org.mosquitto.android.mqtt.MSGRECVD";
    public static final String MQTT_MSG_RECEIVED_TOPIC = "org.mosquitto.android.mqtt.MSGRECVD_TOPIC";
    public static final String MQTT_MSG_RECEIVED_MSG = "org.mosquitto.android.mqtt.MSGRECVD_MSGBODY";
    public static final String MQTT_STATUS_INTENT = "org.mosquitto.android.mqtt.STATUS";
    public static final String MQTT_STATUS_MSG = "org.mosquitto.android.mqtt.STATUS_MSG";
    public static final String MQTT_PING_ACTION = "org.mosquitto.android.mqtt.PING";
    public static final int MAX_MQTT_CLIENTID_LENGTH = 22;

    public static final short KEEP_ALIVE_SECOND = 20 * 60;

    public static final String SAVE_KEY = "SMARTHOMEMQTT";
    public static final String SAVE_KEY_USER_NAME = "username";
    public static final String SAVE_KEY_USER_PASS = "password";
}
