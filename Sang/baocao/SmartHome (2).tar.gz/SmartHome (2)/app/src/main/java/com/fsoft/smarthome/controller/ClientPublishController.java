package com.fsoft.smarthome.controller;

import android.os.Handler;
import android.util.Log;

import com.fsoft.smarthome.activity.SHApplication;
import com.fsoft.smarthome.listenner.ConnectionListenner;

import org.eclipse.paho.android.service.MqttAndroidClient;
import org.eclipse.paho.client.mqttv3.IMqttActionListener;
import org.eclipse.paho.client.mqttv3.IMqttToken;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttMessage;

import static com.fsoft.smarthome.constant.Define.KEEP_ALIVE_SECOND;
import static com.fsoft.smarthome.constant.Define.MQTT_TOPIC;
import static com.fsoft.smarthome.constant.Define.MQTT_URL;
import static com.fsoft.smarthome.constant.Define.TAG;

/**
 * Created by HoangBVN on 5/12/2017.
 */

public class ClientPublishController {

    private static ClientPublishController instance;
    private static MqttAndroidClient client;

    public static ClientPublishController getInstance() {
        if (instance == null) {
            instance = new ClientPublishController();
        }
        return instance;
    }

    public static void connect(final ConnectionListenner listenner) {
        if (client == null) {
            String clientId = MqttClient.generateClientId();
            client = new MqttAndroidClient(SHApplication.getInstance().getApplicationContext(), MQTT_URL, clientId);
            Log.e(TAG, "ClientPublishController create client : " + client);
        }
        if (!client.isConnected()) {
            new Handler().post(new Runnable() {
                @Override
                public void run() {
                    MqttConnectOptions mqttConnectOptions = new MqttConnectOptions();
                    mqttConnectOptions.setCleanSession(true);
                    mqttConnectOptions.setKeepAliveInterval(KEEP_ALIVE_SECOND);

                    try {
                        client.connect(mqttConnectOptions, null, new IMqttActionListener() {
                            @Override
                            public void onSuccess(IMqttToken asyncActionToken) {
                                Log.d(TAG, "ClientPublishController onSuccess");
                                listenner.onSuccess();
                            }

                            @Override
                            public void onFailure(IMqttToken asyncActionToken, Throwable exception) {
                                Log.d(TAG, "ClientPublishController onFailure. Exception when connecting: " + exception);
                                listenner.onFailure();
                            }
                        });
                    } catch (Exception e) {
                        Log.e(TAG, "ClientPublishController Error while connecting to Mqtt broker : " + e);
                        e.printStackTrace();
                    }
                }
            });
        }
    }

    public static void publishMessage(final String payload) {
        try {
            byte[] encodedpayload = payload.getBytes();
            MqttMessage message = new MqttMessage(encodedpayload);
            client.publish(MQTT_TOPIC, message);
            Log.i(TAG, "message successfully published : " + payload);
        } catch (Exception e) {
            Log.e(TAG, "Error when publishing message : " + e);
            e.printStackTrace();
        }
    }

    public static void publishMessage(String topic, final String payload) {
        try {
            byte[] encodedpayload = payload.getBytes();
            MqttMessage message = new MqttMessage(encodedpayload);
            client.publish(topic, message);
            Log.i(TAG, "message successfully published : " + payload);
        } catch (Exception e) {
            Log.e(TAG, "Error when publishing message : " + e);
            e.printStackTrace();
        }
    }

    public static void close() {
        if (client != null) {
            client.unregisterResources();
            client.close();
        }
    }
}
