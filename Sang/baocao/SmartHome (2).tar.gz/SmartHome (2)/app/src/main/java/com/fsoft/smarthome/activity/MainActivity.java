package com.fsoft.smarthome.activity;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import com.fsoft.smarthome.R;
import com.fsoft.smarthome.adapter.DeviceAdapter;
import com.fsoft.smarthome.controller.ClientPublishController;
import com.fsoft.smarthome.dao.Device;
import com.fsoft.smarthome.listenner.StateChangeListenner;
import com.fsoft.smarthome.service.MQTTServiceSimple;
import com.fsoft.smarthome.util.Utils;

import java.util.ArrayList;

import static com.fsoft.smarthome.constant.Define.TAG;
import static com.fsoft.smarthome.constant.Define.MQTT_MSG_RECEIVED_INTENT;
import static com.fsoft.smarthome.constant.Define.MQTT_MSG_RECEIVED_MSG;
import static com.fsoft.smarthome.constant.Define.MQTT_MSG_RECEIVED_TOPIC;

public class MainActivity extends Activity {
    private ListView deviceList;
    DeviceAdapter adapter;
    ArrayList<Device> data;
    private MQTTMessageReceiver messageIntentReceiver;
    private StateChangeListenner listenner;
    ProgressDialog progressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        deviceList = (ListView) findViewById(R.id.deviceList);
        listenner = new StateChangeListenner() {
            @Override
            public void onStateOn() {
                //TODO; publish message to gateway ON device
                ((DeviceAdapter) deviceList.getAdapter()).notifyDataSetChanged();
            }

            @Override
            public void onStateOff() {
                //TODO; publish message to gateway OFF device
                ((DeviceAdapter) deviceList.getAdapter()).notifyDataSetChanged();
            }
        };
        deviceList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Log.d(TAG, "onItemClick i " + i);
            }
        });
        messageIntentReceiver = new MQTTMessageReceiver();
        IntentFilter intentCFilter = new IntentFilter(MQTT_MSG_RECEIVED_INTENT);
        registerReceiver(messageIntentReceiver, intentCFilter);

        progressDialog = new ProgressDialog(this);
        progressDialog.setIndeterminate(true);
        progressDialog.setMessage(getResources().getString(R.string.validating));
        progressDialog.show();
        initData();
//        new android.os.Handler().postDelayed(
//                new Runnable() {
//                    public void run() {
//                        // On complete call either onLoginSuccess or onLoginFailed
//                        initData();
//                        // onLoginFailed();
//                    }
//                }, 3000);
    }

    protected void initData() {
        data = new ArrayList<Device>();
        //TODO: push len gateway yeu cau nhan danh sach data
        Device device = new Device(0, "Đèn phòng khách", 1);
        data.add(device);
        device = new Device(1, "TIVI", 0);
        data.add(device);
        device = new Device(2, "Quạt", 0);
        data.add(device);
        device = new Device(3, "Điều hòa", 1);
        data.add(device);
        device = new Device(4, "Tủ lạnh", 1);
        data.add(device);
    }

    protected void initDataSuccess(){
        progressDialog.hide();
        adapter = new DeviceAdapter(this, data, listenner);
        deviceList.setAdapter(adapter);
        deviceList.deferNotifyDataSetChanged();
    }

    public void logOut(View view) {
        Utils.ClearUser(this);
        Intent intent = new Intent(this, LoginActivity.class);
        startActivity(intent);
        finish();
    }

    public class MQTTMessageReceiver extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
            Bundle notificationData = intent.getExtras();
            /* The topic of this message. */
            String newTopic = notificationData.getString(MQTT_MSG_RECEIVED_TOPIC);
            /* The message payload. */
            String newData = notificationData.getString(MQTT_MSG_RECEIVED_MSG);
            Log.d(TAG, "newTopic " + newTopic + " newData " + newData);
            //TODO: nhan ve danh sach data
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        unregisterReceiver(messageIntentReceiver);

        Intent svc = new Intent(this, MQTTServiceSimple.class);
        stopService(svc);
    }
}
