/*
 * This is an example Android Activity using Dale Lane's MQTTService and the
 * IBM Java library.
 *
 * It is a very simple activity that uses a single text label to display the
 * data coming in on an MQTT topic.
 */
package com.fsoft.smarthome;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.TextView;

import com.fsoft.smarthome.controller.MqttUtil;
import com.fsoft.smarthome.service.MQTTService;
import com.ibm.mqtt.IMqttClient;
import com.ibm.mqtt.MqttClient;
import com.ibm.mqtt.MqttException;

import java.util.Date;

import static com.fsoft.smarthome.constant.Define.APP_ID;
import static com.fsoft.smarthome.constant.Define.KEEP_ALIVE_SECOND;
import static com.fsoft.smarthome.constant.Define.MQTT_BROKER;
import static com.fsoft.smarthome.constant.Define.MQTT_MSG_RECEIVED_INTENT;
import static com.fsoft.smarthome.constant.Define.MQTT_MSG_RECEIVED_MSG;
import static com.fsoft.smarthome.constant.Define.MQTT_MSG_RECEIVED_TOPIC;
import static com.fsoft.smarthome.constant.Define.MQTT_STATUS_INTENT;
import static com.fsoft.smarthome.constant.Define.MQTT_STATUS_MSG;
import static com.fsoft.smarthome.constant.Define.MQTT_TOPIC;
import static com.fsoft.smarthome.constant.Define.MQTT_URL;

public class MQTTDemo extends Activity {
    private TextView mText = null;
    private StatusUpdateReceiver statusUpdateIntentReceiver;
    private MQTTMessageReceiver messageIntentReceiver;
    private IMqttClient client;

    /**
     * Called when the activity is first created.
     */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        mText = (TextView) findViewById(R.id.text);

        SharedPreferences settings = getSharedPreferences(APP_ID, 0);
        SharedPreferences.Editor editor = settings.edit();
        editor.putString("broker", MQTT_BROKER); // CHANGE ME to your broker address
        editor.putString("topic", MQTT_TOPIC); // CHANGE ME to your topic
        editor.commit();

        statusUpdateIntentReceiver = new StatusUpdateReceiver();
        IntentFilter intentSFilter = new IntentFilter(MQTT_STATUS_INTENT);
        registerReceiver(statusUpdateIntentReceiver, intentSFilter);

        messageIntentReceiver = new MQTTMessageReceiver();
        IntentFilter intentCFilter = new IntentFilter(MQTT_MSG_RECEIVED_INTENT);
        registerReceiver(messageIntentReceiver, intentCFilter);

        Intent svc = new Intent(this, MQTTService.class);
        startService(svc);
        try {
            client = MqttClient.createMqttClient(MQTT_URL, null);
        } catch (MqttException e) {
            e.printStackTrace();
        }
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {

                    // Get Mqtt client singleton instance
                    MqttUtil.getClient(MQTTDemo.this);
                    client.connect(MqttUtil.generateClientId(MQTTDemo.this), false, KEEP_ALIVE_SECOND);
                } catch (MqttException e) {
                    e.printStackTrace();
                }
            }
        }).start();
    }

    public class StatusUpdateReceiver extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
            Bundle notificationData = intent.getExtras();
            String newStatus = notificationData.getString(MQTT_STATUS_MSG);
            mText.setText(newStatus);
        }
    }

    public class MQTTMessageReceiver extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
            Bundle notificationData = intent.getExtras();
            /* The topic of this message. */
            String newTopic = notificationData.getString(MQTT_MSG_RECEIVED_TOPIC);
            /* The message payload. */
            String newData = notificationData.getString(MQTT_MSG_RECEIVED_MSG);

			/* Display the payload on the text label. */
            mText.setText(newData + "\n" + newTopic);
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Intent svc = new Intent(this, MQTTService.class);
        stopService(svc);

        unregisterReceiver(statusUpdateIntentReceiver);
        unregisterReceiver(messageIntentReceiver);
    }

    public void pubMessage(View view) {
        MqttUtil.publishMessage("Hello Android MQTT");
    }
}
