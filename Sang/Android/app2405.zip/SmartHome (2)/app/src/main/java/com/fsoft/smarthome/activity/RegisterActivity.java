package com.fsoft.smarthome.activity;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.fsoft.smarthome.R;
import com.fsoft.smarthome.controller.ClientPublishController;
import com.fsoft.smarthome.util.Utils;

import static com.fsoft.smarthome.constant.Define.TAG;
import static com.fsoft.smarthome.constant.Define.MQTT_MSG_RECEIVED_INTENT;
import static com.fsoft.smarthome.constant.Define.MQTT_MSG_RECEIVED_MSG;
import static com.fsoft.smarthome.constant.Define.MQTT_MSG_RECEIVED_TOPIC;
import static com.fsoft.smarthome.constant.Define.TOPIC_USER_REG;

public class RegisterActivity extends Activity {
    private MQTTMessageReceiver messageIntentReceiver;

    LinearLayout loginForm;
    EditText userNameInput, userPassInput;
    String userName, userPass;
    CheckBox saveLogin;
    Button register;
    ProgressDialog progressDialog;
    boolean isProgressing;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        loginForm = (LinearLayout) findViewById(R.id.login_form);
        userNameInput = (EditText) findViewById(R.id.user_name);
        userPassInput = (EditText) findViewById(R.id.user_pass);
        saveLogin = (CheckBox) findViewById(R.id.save_login);
        register = (Button) findViewById(R.id.login);
        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                register();
            }
        });
        progressDialog = new ProgressDialog(this);
        progressDialog.setIndeterminate(true);
        progressDialog.setMessage(getResources().getString(R.string.validating));
        isProgressing = false;
        messageIntentReceiver = new MQTTMessageReceiver();
        IntentFilter intentCFilter = new IntentFilter(MQTT_MSG_RECEIVED_INTENT);
        registerReceiver(messageIntentReceiver, intentCFilter);
    }

    protected void loginSaved() {
        if (isProgressing) {
            return;
        }
        if (Utils.IsUserSaved(this)) {
            userName = Utils.GetUserSaved(this);
            userPass = Utils.GetPasswordSaved(this);
            loginForm.setVisibility(View.GONE);
            isProgressing = true;
            progressDialog.show();
            validate(userName, userPass);
        }
    }

    protected void register() {
        if (isProgressing) {
            return;
        }
        isProgressing = true;
        userName = String.valueOf(userNameInput.getText());
        userPass = String.valueOf(userPassInput.getText());
        progressDialog.show();
        validate(userName, userPass);

    }

    protected void validate(String username, String userpass) {
        Log.d(TAG, "username " + username + " userpass " + userpass);
        ClientPublishController.getInstance().publishMessage(TOPIC_USER_REG, username + ";" + userpass);
//        new android.os.Handler().postDelayed(
//                new Runnable() {
//                    public void run() {
//                        // On complete call either onLoginSuccess or onLoginFailed
                       onRegisterSuccess();
//                        // onLoginFailed();
//                    }
//                }, 300);
    }

    @Override
    public void onBackPressed() {
        // disable going back to the MainActivity
        moveTaskToBack(true);
    }

    public void onRegisterSuccess() {
        Log.d(TAG, "saveLogin.isChecked()" + saveLogin.isChecked());
        if (saveLogin.isChecked()) {
            Utils.SaveUser(this, userName, userPass);
        }
        progressDialog.dismiss();
        isProgressing = false;
        changeScreen();
    }

    public void onRegisterFailed() {
        Toast.makeText(getBaseContext(), "Login failed", Toast.LENGTH_LONG).show();
        loginForm.setVisibility(View.VISIBLE);
        progressDialog.dismiss();
        isProgressing = false;
    }

    protected void changeScreen() {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
        finish();
    }

    public class MQTTMessageReceiver extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
            Bundle notificationData = intent.getExtras();
            /* The topic of this message. */
            String newTopic = notificationData.getString(MQTT_MSG_RECEIVED_TOPIC);
            /* The message payload. */
            String newData = notificationData.getString(MQTT_MSG_RECEIVED_MSG);
            Log.d(TAG, "newTopic " + newTopic + " newData " + newData);
            if(newTopic.equals(TOPIC_USER_REG) && newData.contains("0")){
                onRegisterSuccess();
            }
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        unregisterReceiver(messageIntentReceiver);
    }
}

