package com.fsoft.smarthome.service;

import android.app.Service;
import android.content.Intent;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.util.Log;
import android.widget.Toast;

import com.ibm.mqtt.IMqttClient;
import com.ibm.mqtt.MqttClient;
import com.ibm.mqtt.MqttPersistenceException;
import com.ibm.mqtt.MqttSimpleCallback;

import org.eclipse.paho.client.mqttv3.MqttException;

import static com.fsoft.smarthome.constant.Define.MQTT_TOPIC;
import static com.fsoft.smarthome.constant.Define.MQTT_URL;
import static org.eclipse.paho.client.mqttv3.MqttAsyncClient.generateClientId;


/*
* Nice implmentation that supports keep alive and reconnect things:
* https://github.com/JesseFarebro/Android-Paho-MQTT-Service/blob/master/src/com/jessefarebro/mqtt/MqttService.java
*
* Useful article on MQTT, Android and Paho client
* http://www.infoq.com/articles/practical-mqtt-with-paho
*
* */

public class MQTTService2 extends Service {

    private static final String THREAD_NAME = "pahoThread";
    private IMqttClient mqttClient;
    private Handler connectionHandler;
    private MqttPahoCallback mqttCallback;

    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onStart(Intent intent, int startId) {
        super.onStart(intent, startId);

        HandlerThread thread = new HandlerThread(THREAD_NAME);
        thread.start();
        mqttCallback = new MqttPahoCallback();
        connectionHandler = new Handler(thread.getLooper());
        startConnection();
//
//        registerReceiver(new BroadcastReceiver() {
//            @Override
//            public void onReceive(Context context, Intent intent) {
//                Toast.makeText(context, "Network connected.", Toast.LENGTH_SHORT).show();
//                Log.d("Service", "Network connected");
//                startConnection();
//            }
//        }, new IntentFilter(Constants.INTENT_NETWORK_CONNECTED));
//
//        registerReceiver(new BroadcastReceiver() {
//            @Override
//            public void onReceive(Context context, Intent intent) {
//                Toast.makeText(context, "Network not connected.", Toast.LENGTH_SHORT).show();
//                Log.d("Service", "No network");
//            }
//        }, new IntentFilter(Constants.INTENT_NETWORK_DISCONNECTED));
    }

    private void startConnection() {
        connectionHandler.post(new Runnable() {
            @Override
            public void run() {

//                try {
//                    mqttClient = new MqttClient.createMqttClient(MQTT_URL, null);
//
//                    mqttClient.registerSimpleHandler(mqttCallback);
//                    try {
//                        mqttClient.connect(generateClientId(), false, (short) (20*60));
//                    } catch (com.ibm.mqtt.MqttException e) {
//                        e.printStackTrace();
//                    }
//
//                    //Subscribe to all subtopics of homeautomation
//                    mqttClient.subscribe(MQTT_TOPIC);
//
//
//                } catch (MqttException e) {
//                    Log.e("MQTTService", e.getMessage(), e);
//                }
            }
        });

    }

    @Override
    public void onDestroy() {
            try {
                mqttClient.disconnect();
            } catch (MqttPersistenceException e) {
                e.printStackTrace();
                Toast.makeText(getApplicationContext(), "Something went wrong!" + e.getMessage(), Toast.LENGTH_LONG).show();
                e.printStackTrace();
            }
    }


        protected class MqttPahoCallback implements MqttSimpleCallback {

            @Override
            public void connectionLost() throws Exception {

            }

            @Override
            public void publishArrived(String s, byte[] bytes, int i, boolean b) throws Exception {

            }
        }
    }
