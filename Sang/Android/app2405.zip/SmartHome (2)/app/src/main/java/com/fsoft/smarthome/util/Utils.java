package com.fsoft.smarthome.util;

import android.content.Context;
import android.content.SharedPreferences;

import static com.fsoft.smarthome.constant.Define.SAVE_KEY;
import static com.fsoft.smarthome.constant.Define.SAVE_KEY_USER_NAME;
import static com.fsoft.smarthome.constant.Define.SAVE_KEY_USER_PASS;

/**
 * Created by HoangBVN on 5/10/2017.
 */

public class Utils {
    public static boolean IsUserSaved(Context context) {
        SharedPreferences sharedPreferences = context.getSharedPreferences(SAVE_KEY, Context.MODE_PRIVATE);
        String username = GetUserSaved(context);
        String userpass = GetPasswordSaved(context);
        return (username != null && userpass != null);
    }

    public static boolean ClearUser(Context context) {
        SharedPreferences sharedPreferences = context.getSharedPreferences(SAVE_KEY, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(SAVE_KEY_USER_NAME, null);
        editor.putString(SAVE_KEY_USER_PASS, null);
        return editor.commit();
    }

    public static String GetUserSaved(Context context) {
        SharedPreferences sharedPreferences = context.getSharedPreferences(SAVE_KEY, Context.MODE_PRIVATE);
        return sharedPreferences.getString(SAVE_KEY_USER_NAME, null);
    }

    public static String GetPasswordSaved(Context context) {
        SharedPreferences sharedPreferences = context.getSharedPreferences(SAVE_KEY, Context.MODE_PRIVATE);
        return sharedPreferences.getString(SAVE_KEY_USER_PASS, null);
    }

    public static boolean SaveUser(Context context, String username, String userpass) {
        SharedPreferences sharedPreferences = context.getSharedPreferences(SAVE_KEY, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(SAVE_KEY_USER_NAME, username);
        editor.putString(SAVE_KEY_USER_PASS, username);
        return editor.commit();
    }

}
