package com.fsoft.smarthome.controller;

import android.content.Context;
import android.provider.Settings;
import android.util.Log;

import org.eclipse.paho.android.service.MqttAndroidClient;
import org.eclipse.paho.client.mqttv3.IMqttActionListener;
import org.eclipse.paho.client.mqttv3.IMqttToken;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttMessage;

import java.util.Date;

import static com.fsoft.smarthome.constant.Define.KEEP_ALIVE_SECOND;
import static com.fsoft.smarthome.constant.Define.MQTT_BROKER;
import static com.fsoft.smarthome.constant.Define.MQTT_TOPIC;
import static com.fsoft.smarthome.constant.Define.MQTT_URL;

/**
 * Created by HoangBVN on 5/8/2017.
 */

public class MqttUtil {
    private static boolean published;
    private static MqttAndroidClient client;
    private static final String TAG = MqttUtil.class.getName();


    public static MqttAndroidClient getClient(Context context) {
        if (client == null) {
            String clientId = MqttClient.generateClientId();
            client = new MqttAndroidClient(context, MQTT_URL, clientId);
            Log.e(TAG, "MqttUtil getClient client : " + client);
        }
        if (!client.isConnected())
            connect();
        return client;
    }

    private static void connect() {
        MqttConnectOptions mqttConnectOptions = new MqttConnectOptions();
        mqttConnectOptions.setCleanSession(true);
        mqttConnectOptions.setKeepAliveInterval(KEEP_ALIVE_SECOND);

        try {
            client.connect(mqttConnectOptions, null, new IMqttActionListener() {
                @Override
                public void onSuccess(IMqttToken asyncActionToken) {
                    Log.d(TAG, "onSuccess");
                }

                @Override
                public void onFailure(IMqttToken asyncActionToken, Throwable exception) {
                    Log.d(TAG, "onFailure. Exception when connecting: " + exception);
                }
            });
        } catch (Exception e) {
            Log.e(TAG, "Error while connecting to Mqtt broker : " + e);
            e.printStackTrace();
        }
    }

    public static void publishMessage(final String payload) {
        published = false;
        try {
            byte[] encodedpayload = payload.getBytes();
            MqttMessage message = new MqttMessage(encodedpayload);
            client.publish(MQTT_TOPIC, message);
            published = true;
            Log.i(TAG, "message successfully published : " + payload);
        } catch (Exception e) {
            Log.e(TAG, "Error when publishing message : " + e);
            e.printStackTrace();
        }
    }

    public static void close() {
        if (client != null) {
            client.unregisterResources();
            client.close();
        }
    }

    public static String generateClientId(Context context) {
        String mqttClientId = null;
        int MAX_MQTT_CLIENTID_LENGTH = 22;
        if (mqttClientId == null) {
            String timestamp = "" + (new Date()).getTime();
            String android_id = Settings.System.getString(context.getContentResolver(),
                    Settings.Secure.ANDROID_ID);
            mqttClientId = timestamp + android_id;

            if (mqttClientId.length() > MAX_MQTT_CLIENTID_LENGTH) {
                mqttClientId = mqttClientId.substring(0, MAX_MQTT_CLIENTID_LENGTH);
            }
        }

        return mqttClientId;
    }
}
