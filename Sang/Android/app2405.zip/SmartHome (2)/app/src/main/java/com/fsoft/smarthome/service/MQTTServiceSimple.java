package com.fsoft.smarthome.service;

import android.app.Service;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.util.Log;
import android.widget.Toast;

import com.fsoft.smarthome.controller.MqttUtil;
import com.ibm.mqtt.IMqttClient;
import com.ibm.mqtt.MqttClient;
import com.ibm.mqtt.MqttException;
import com.ibm.mqtt.MqttPersistence;
import com.ibm.mqtt.MqttPersistenceException;
import com.ibm.mqtt.MqttSimpleCallback;

import static com.fsoft.smarthome.constant.Define.TAG;
import static com.fsoft.smarthome.constant.Define.APP_ID;
import static com.fsoft.smarthome.constant.Define.KEEP_ALIVE_SECOND;
import static com.fsoft.smarthome.constant.Define.MQTT_MSG_RECEIVED_INTENT;
import static com.fsoft.smarthome.constant.Define.MQTT_MSG_RECEIVED_MSG;
import static com.fsoft.smarthome.constant.Define.MQTT_MSG_RECEIVED_TOPIC;
import static com.fsoft.smarthome.constant.Define.MQTT_URL;
import static com.fsoft.smarthome.constant.Define.TOPIC_HOME_DEVICE;

public class MQTTServiceSimple extends Service implements MqttSimpleCallback {

    private static final String THREAD_NAME = "pahoThread";
    private IMqttClient mqttClient;
    private Handler connectionHandler;
    private String brokerHostName = "";
    private String topicName = "";
    private int[] qualitiesOfService = {0};
    private MqttPersistence usePersistence = null;

    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onStart(Intent intent, int startId) {
        super.onStart(intent, startId);

        HandlerThread thread = new HandlerThread(THREAD_NAME);
        thread.start();
        connectionHandler = new Handler(thread.getLooper());
        SharedPreferences settings = getSharedPreferences(APP_ID, MODE_PRIVATE);
        brokerHostName = settings.getString("broker", "");
        topicName = settings.getString("topic", "");
        startConnection();

    }

    private void startConnection() {
        connectionHandler.post(new Runnable() {
            @Override
            public void run() {

                try {
                    mqttClient = MqttClient.createMqttClient(MQTT_URL, usePersistence);

                    mqttClient.registerSimpleHandler(MQTTServiceSimple.this);

                    mqttClient.connect(MqttUtil.generateClientId(MQTTServiceSimple.this), false, KEEP_ALIVE_SECOND);

                    String[] topics = {topicName};
                    Log.d(TAG, "topicName " + topicName);
                    mqttClient.subscribe(topics, qualitiesOfService);

                    mqttClient.subscribe(new String[]{TOPIC_HOME_DEVICE}, qualitiesOfService);

                } catch (MqttException e) {
                    Log.e("MQTTService", e.getMessage(), e);
                }
            }
        });

    }

    @Override
    public void onDestroy() {
        try {
            mqttClient.disconnect();
        } catch (MqttPersistenceException e) {
            e.printStackTrace();
            Toast.makeText(getApplicationContext(), "Something went wrong!" + e.getMessage(), Toast.LENGTH_LONG).show();
            e.printStackTrace();
        }
    }

    @Override
    public void connectionLost() throws Exception {

    }

    @Override
    public void publishArrived(String s, byte[] bytes, int i, boolean b) throws Exception {
        String messageBody = new String(bytes);
        Log.d(TAG, "s " + s + " bytes " + messageBody);
        //TODO: ket noi duoc voi gateway, va nhan topic moi
//        String[] topics = {topic moi};
//        mqttClient.subscribe(topics, qualitiesOfService);
        broadcastReceivedMessage(s, messageBody);
    }

    private void broadcastReceivedMessage(String topic, String message) {
        Intent broadcastIntent = new Intent();
        broadcastIntent.setAction(MQTT_MSG_RECEIVED_INTENT);
        broadcastIntent.putExtra(MQTT_MSG_RECEIVED_TOPIC, topic);
        broadcastIntent.putExtra(MQTT_MSG_RECEIVED_MSG, message);
        sendBroadcast(broadcastIntent);
    }

//    public static void setTopic(String topicName){
//
//        String[] topics = {topicName};
//        Log.d(TAG, "topicName " + topicName);
//        mqttClient.subscribe(topics, qualitiesOfService);
//    }
}
