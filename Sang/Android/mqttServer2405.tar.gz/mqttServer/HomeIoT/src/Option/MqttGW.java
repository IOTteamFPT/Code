package Option;

import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence;

public class MqttGW {
	public static final String TOPIC_USER_LOGIN = "house/login/user";
	public static final String TOPIC_HOUSE_REG = "house/register/house";
	public static final String TOPIC_USER_REG = "house/register/user";
	public static final String TOPIC_USER_UPDATE = "house/User/update/user";
	public static final String TOPIC_PASS_UPDATE = "house/User/update/pass";
	public static final String TOPIC_HOUSE_UPDATE = "house/User/update/house";
	public static final String TOPIC_HOUSE_GET = "house/get";
	public static final String TOPIC_USER_DELETE = "house/delete/user";
	public static final String TOPIC_HOUSE_DELETE = "house/delete/house";

	public MqttGW() {
	}

	/*
	 * Recive message respond Server
	 */
	public void Server_Respond(String topic, int qos) {
		String broker = "tcp://localhost:1883";
		String clientId = MqttClient.generateClientId();

		FuncOption opt = new FuncOption();
		opt.sqlOpen("localhost", "root", "");
		MemoryPersistence persistence = new MemoryPersistence();
		try {
			final MqttClient sampleClient = new MqttClient(broker, clientId, persistence);
			MqttConnectOptions connOpts = new MqttConnectOptions();

			sampleClient.connect(connOpts);
			sampleClient.subscribe(topic, qos);
			// sampleClient.disconnect();

		} catch (Exception me) {

			me.printStackTrace();
		}
	}

	public void run() {
		String broker = "tcp://localhost:1883";
		String clientId = MqttClient.generateClientId();
		MemoryPersistence persistence = new MemoryPersistence();
		try {
			final MqttClient sampleClient = new MqttClient(broker, clientId, persistence);
			MqttConnectOptions connOpts = new MqttConnectOptions();
			System.out.println("Connecting to broker: " + broker);
			sampleClient.connect(connOpts);
			System.out.println("Connected");

			sampleClient.setCallback(new MqttCallback() {

				public void connectionLost(Throwable cause) {
					System.out.println("connectionLost-----------1" + cause);
				}

				public void deliveryComplete(IMqttDeliveryToken token) {
					System.out.println("deliveryComplete---------2" + token.isComplete());
				}

				public void messageArrived(String topic, MqttMessage arg1) throws Exception {
					System.out.println("messageArrived----------3 " + topic + " " + arg1.toString());

					switch (topic) {
					case TOPIC_USER_DELETE:
						// sampleClient.subscribe(topic);
						// Server_Respond(topic, 0);
						break;

					default:
						break;
					}
				}
			});
			sampleClient.publish(TOPIC_USER_LOGIN, "LOGIN_USER".getBytes(), 2, true);
			sampleClient.publish(TOPIC_HOUSE_REG, "HOUSE_REGISTER".getBytes(), 2, true);
			sampleClient.publish(TOPIC_USER_REG, "USER_REGISTER".getBytes(), 2, true);
			sampleClient.publish(TOPIC_USER_UPDATE, "UPDATE_USER".getBytes(), 2, true);
			sampleClient.publish(TOPIC_PASS_UPDATE, "UPDATE_PASS".getBytes(), 2, true);
			sampleClient.publish(TOPIC_HOUSE_UPDATE, "UPDATE_HOUSE".getBytes(), 2, true);
			sampleClient.publish(TOPIC_HOUSE_GET, "HOUSE_GET".getBytes(), 2, true);
			sampleClient.publish(TOPIC_USER_DELETE, "USER_DELETE".getBytes(), 0, true);
			sampleClient.publish(TOPIC_HOUSE_DELETE, "HOUSE_DELETE".getBytes(), 0, true);
			// sampleClient.disconnect();

		} catch (MqttException me) {
			System.out.println("reason " + me.getReasonCode());
			System.out.println("msg " + me.getMessage());
			System.out.println("loc " + me.getLocalizedMessage());
			System.out.println("cause " + me.getCause());
			System.out.println("excep " + me);
			me.printStackTrace();
		}

	}

}
