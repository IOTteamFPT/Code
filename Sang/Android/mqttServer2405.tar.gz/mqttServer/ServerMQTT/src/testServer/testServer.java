package testServer;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.concurrent.CountDownLatch;

import org.apache.commons.lang.SerializationUtils;
import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import Fpt.IoT.HomeMonitoring.LoginHouse;
import Fpt.IoT.HomeMonitoring.addHome;
import Fpt.IoT.HomeMonitoring.digitalControl;
import Fpt.IoT.HomeMonitoring.getimforHouse;
import Fpt.IoT.HomeMonitoring.getimforUser;
import Fpt.IoT.HomeMonitoring.publish_Server_to_Client;
import Fpt.IoT.HomeMonitoring.registerHouse;
import Fpt.IoT.HomeMonitoring.registerUser;
import Fpt.IoT.HomeMonitoring.sqlOpen;

public class testServer {

	public PreparedStatement statement;
	public Connection sqlConn;
	public CountDownLatch latch;
	public JSONParser parser = new JSONParser();
	public publish_Server_to_Client pub = new publish_Server_to_Client();

	/*------topic---------*/
	public static final String TOPIC_USER_REG = "house/register/user";
	public static final String TOPIC_LED = "app/digital_device";
	public static final String TOPIC_HOUSE_GET = "house/get/user";
	public static final String TOPIC_HOUSE_ADD = "house/add/house";
	public static final String TOPIC_HOUSE_REG = "house/register/house";
	public static final String TOPIC_HOME_GET = "house/get/house";
	public static final String TOPIC_HOME_LOGIN = "house/login";

	public static void main(String[] args) throws MqttException {
		testServer Server = new testServer();
		Server.run();

	}

	/*------------run program--------------*/
	public void run() throws MqttException {
		String broker = "tcp://localhost:1883";

		String clientId = MqttClient.generateClientId();
		sqlOpen opt = new sqlOpen();
		registerUser reg = new registerUser();
		opt.sql_Open("localhost", "root", "");
		MemoryPersistence persistence = new MemoryPersistence();
		try {
			final MqttClient Server = new MqttClient(broker, clientId, persistence);
			MqttConnectOptions connOpts = new MqttConnectOptions();
			System.out.println("Connecting to broker: " + broker);
			connOpts.setCleanSession(true);
			connOpts.setKeepAliveInterval(6000);

			Server.connect(connOpts);
			System.out.println("Connected");
			/*---------MQTT CALLBACK------------*/
			Server.setCallback(new MqttCallback() {

				public void connectionLost(Throwable cause) {
					System.out.println("connectionLost-----------111111" + cause);
					// latch.countDown();
					cause.printStackTrace();
				}

				public void messageArrived(String topic, MqttMessage arg1) throws Exception {
					// String time = new
					// Timestamp(System.currentTimeMillis()).toString();
					System.out.println("topic " + topic);
					System.out.println("arg1 " + arg1);
					switch (topic) {

					case TOPIC_USER_REG:
						System.out.println("TOPIC_USER_REG arg1 " + arg1);
						String[] user = arg1.toString().split(";");
						if (user.length <= 1)
							break;

						int user_id = reg.register_User(user[0], user[1]);
						String User_ID = Integer.toString(user_id);

						if (user[0].equals(user[1])) {
							arg1.setPayload((" 1 " + User_ID + ";").getBytes());
							// Thread.sleep(1000);
							pub.publish_Server_to_client(topic, arg1);
						} else {
							MqttMessage msg = new MqttMessage();
							msg.setPayload((" 0 " + "\n" + User_ID).getBytes());
							// Thread.sleep(1000);

							pub.publish_Server_to_client(topic, msg);
							System.out.println("ok");

						}

						break;
					case TOPIC_LED:

						digitalControl dig = new digitalControl();

						// String data1 = "0,1,0,1,0";
						byte[] data = SerializationUtils.serialize((Serializable) dig);
						String[] led = arg1.toString().split(" ");
						if (led.length <= 1)
							break;

						boolean app = true;
						System.out.println("ok2");
						if (app == true) {
							// arg1.setPayload(data1.getBytes());
							arg1.setPayload(data);
							Thread.sleep(1000);
							pub.publish_Server_to_client(topic, arg1);
							System.out.println("Control led success");
						} else
							arg1.setPayload("Ban da that bai".getBytes());
						Thread.sleep(1000);
						pub.publish_Server_to_client(topic, arg1);

						break;
					case TOPIC_HOUSE_GET:

						String get_User = arg1.toString();
						if (get_User.length() <= 2)
							break;

						JSONObject obj = new JSONObject();
						getimforUser get = new getimforUser();

						obj = get.getimfor_User(get_User);
						String respPayload = obj.toJSONString();
						MqttMessage respMessage = new MqttMessage(respPayload.getBytes());
						// Thread.sleep(1000);
						// respMessage.setQos(2);
						pub.publish_Server_to_client(topic, respMessage);

						break;
					case TOPIC_HOUSE_ADD:

						String[] add = new String[2];
						add = arg1.toString().split(";");

						if (add.length <= 1)
							break;

						addHome addhome = new addHome();

						addhome.add_Home(add[0], add[1]);

						MqttMessage message = new MqttMessage();
						if (add[0].equals(add[1])) {
							message.setPayload(("Fail").getBytes());
							// Thread.sleep(1000);
							pub.publish_Server_to_client(topic, message);

						} else {
							message.setPayload(("1").getBytes());
							message.setQos(2);
							message.setRetained(true);
							// Thread.sleep(1000);
							pub.publish_Server_to_client(topic, message);
						}
						break;
					case TOPIC_HOME_GET:

						String get_house = arg1.toString();
						if (get_house.length() <= 1)
							break;

						JSONObject obj1 = new JSONObject();
						getimforHouse get1 = new getimforHouse();

						obj1 = get1.getimfor_House((get_house));
						String respPayload1 = obj1.toJSONString();
						MqttMessage respMessage1 = new MqttMessage(respPayload1.getBytes());
						// Thread.sleep(1000);
						// respMessage.setQos(2);
						pub.publish_Server_to_client(topic, respMessage1);
						// Thread.sleep(1000);

						break;

					case TOPIC_HOUSE_REG:
						String[] home = new String[3];
						home = arg1.toString().split(",");

						if (home.length <= 1)
							break;

						registerHouse reg = new registerHouse();

						reg.register_House(home[0], home[1], (home[2]));
						if (home[0].equals(home[1])) {

							MqttMessage msg = new MqttMessage();
							msg.setPayload(("1").getBytes());
							// Thread.sleep(1000);

							pub.publish_Server_to_client(topic, msg);
						} else {
							MqttMessage msg = new MqttMessage();
							msg.setPayload(("0").getBytes());
							// Thread.sleep(1000);

							pub.publish_Server_to_client(topic, msg);

						}
						break;

					case TOPIC_HOME_LOGIN:
						// JSONParser jsonParser = new JSONParser();
						// JSONObject object = (JSONObject)
						// jsonParser.parse(arg1);
						String[] login = new String[2];
						login = arg1.toString().split(",");

						Object payloadObject = parser.parse(new String(arg1.getPayload()));
						JSONObject jsonPayload = (JSONObject) payloadObject;
						String LoginSuccessFlag = "" + jsonPayload.get("LoginSuccessFlag");
						String GatewayRegisteredFlag = "" + jsonPayload.get("GatewayRegisteredFlag");

						JSONObject obj11 = new JSONObject();
						obj11.put("GatewayRegisteredFlag", 1);
						obj11.put("LoginSuccessFlag", 1);

						String resPayload = obj11.toJSONString();
						MqttMessage msg = new MqttMessage(resPayload.getBytes());

						if (login.length <= 2)
							break;
						System.err.println("ok1");
						System.err.println("ok3");
						LoginHouse login_house = new LoginHouse();
						login_house.Login_House(login[0], login[1]);
						System.err.println("ok2");

						if (login[0].equals(login[1])) {

							pub.publish_Server_to_client(topic, msg);
							System.err.println("Success");

						} else {

							pub.publish_Server_to_client(topic, msg);
							System.err.println("Fail");

						}
						break;

					// case TOPIC_HOUSE_REG:
					//
					// String[] home = new String[3];
					// home = arg1.toString().split(",");
					//
					// if (home.length <= 2)
					// break;
					// System.out.println("1111");
					//
					// testHouse reg = new testHouse();
					// System.out.println("2222");
					//
					// reg.test_House(home[0], home[1], (home[2]));
					// System.out.println("OK");
					//
					// if (home[0].equals(home[1])) {
					//
					// MqttMessage msg = new MqttMessage();
					// msg.setPayload(("1").getBytes());
					//
					// pub.publish_Server_to_client(topic, msg);
					// } else {
					// MqttMessage msg = new MqttMessage();
					// msg.setPayload(("0").getBytes());
					//
					// pub.publish_Server_to_client(topic, msg);
					//
					// }
					// break;

					default:
						break;
					}
				}

				public void deliveryComplete(IMqttDeliveryToken token) {
					System.out.println("deliveryComplete---------2" + token.isComplete());
				}
			});
			Server.subscribe(TOPIC_USER_REG);
			Server.subscribe(TOPIC_LED);
			Server.subscribe(TOPIC_HOUSE_GET);
			Server.subscribe(TOPIC_HOUSE_ADD);
			Server.subscribe(TOPIC_HOUSE_REG);
			Server.subscribe(TOPIC_HOME_GET);
			Server.subscribe(TOPIC_HOME_LOGIN);

		} catch (MqttException me) {
			System.out.println("msg " + me.getMessage());
			System.out.println("loc " + me.getLocalizedMessage());
			System.out.println("cause " + me.getCause());
			System.out.println("excep " + me);
			me.printStackTrace();

		}

	}

}
// http://code4lifevn.blogspot.com/2013/08/su-dung-json-trong-lap-trinh-java.html
