package Fpt.IoT.HomeMonitoring;

import org.json.simple.JSONAware;

public class registerHomeJson implements JSONAware {

	private String UserName;
	private String PassWord;
	private String MAC_Add;

	public registerHomeJson() {

	}

	public registerHomeJson(String UserName, String PassWord, String MAC_Add) {
		super();
		this.UserName = UserName;
		this.PassWord = PassWord;
		this.MAC_Add = MAC_Add;
	}

	public String getUserName() {
		return this.UserName;
	}

	public void setUserName(String UserName) {
		UserName = this.UserName;
	}

	public String getPasWord() {
		return this.PassWord;
	}

	public void setPasWord(String PassWord) {
		PassWord = this.PassWord;
	}

	public String getMAC_Add() {
		return this.MAC_Add;
	}

	public void setMAC_Add(String MAC_Add) {
		MAC_Add = this.MAC_Add;
	}

	public String toJSONString() {
		StringBuffer sb = new StringBuffer();
		sb.append("{");

		sb.append("\"UserName\":\"" + getUserName() + "\"");

		sb.append(",");

		sb.append("\"PassWord\":\"" + getPasWord() + "\"");
		sb.append(",");

		sb.append("\"MAC_Add\":\"" + getMAC_Add() + "\"");

		sb.append("}");

		return sb.toString();

	}

}
