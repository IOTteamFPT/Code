package Fpt.IoT.HomeMonitoring;

import java.sql.Timestamp;
import java.util.concurrent.CountDownLatch;

import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence;

public class topicSubscriber {
	public topicSubscriber() {

	}

	public void run() {
		String broker = "tcp://localhost:1883";
		String clientId = MqttClient.generateClientId();

		MemoryPersistence persistence = new MemoryPersistence();
		try {
			final MqttClient Server = new MqttClient(broker, clientId, persistence);
			MqttConnectOptions connOpts = new MqttConnectOptions();
			connOpts.setCleanSession(true);
			Server.connect(connOpts);
			System.out.println("Connected");
			final CountDownLatch latch = new CountDownLatch(1);
			final String subTopic = "pubsub";
			Server.setCallback(new MqttCallback() {

				public void messageArrived(String topic, MqttMessage message) throws Exception {
					String time = new Timestamp(System.currentTimeMillis()).toString();
					System.out.println("\n Receive a message !" + "\n\tTime" + time + "\n\tTopic" + topic
							+ "\n\tMessage " + new String(message.getPayload()) + "n\tQos" + message.getQos() + "\n");
					latch.countDown();

				}

				public void deliveryComplete(IMqttDeliveryToken cause) {
					try {
						System.out.println("Connection to broker lost" + cause.getMessage());
					} catch (MqttException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}

				}

				public void connectionLost(Throwable arg0) {
					latch.countDown();

				}
			});
			System.out.println("Subscribing to topic : " + subTopic);
			Server.subscribe(subTopic, 0);
			try {
				latch.await();
			} catch (InterruptedException e) {
				e.printStackTrace();
				System.out.println("I was awoken while waiting");

			}
			Server.disconnect();
			System.out.println("Exiting");

		} catch (MqttException ex) {
			ex.printStackTrace();

		}
	}

}
