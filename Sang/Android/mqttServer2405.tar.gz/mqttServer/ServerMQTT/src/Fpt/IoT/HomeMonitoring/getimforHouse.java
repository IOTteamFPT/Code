package Fpt.IoT.HomeMonitoring;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.json.simple.JSONObject;

public class getimforHouse {
	public String ID;
	public java.sql.Connection sqlConn = null;

	public getimforHouse() {

	}

	public JSONObject getimfor_House(String ID) throws SQLException {
		DatabaseConnect Conn = new DatabaseConnect();
		sqlConn = Conn.getConnectMysql();
		PreparedStatement pt = null;
		ResultSet rs = null;
		this.ID = ID;
		try {
			sqlConn.setAutoCommit(false);

			String sql = "SELECT  UserName,PassWord,MAC_Add FROM Home WHERE ID = ? ";
			pt = sqlConn.prepareStatement(sql);
			pt.setString(1, ID);
			rs = pt.executeQuery();
			JSONObject jsonObject = new JSONObject();
			JSONObject json = new JSONObject();
			while (rs.next()) {
				String UserName = rs.getString(1);
				String PassWord = rs.getString(2);
				String MAC_Add = rs.getString(3);

				jsonObject.put("UserName", UserName);
				jsonObject.put("PassWord", PassWord);
				jsonObject.put("MAC_Add", MAC_Add);
				json.put("imformation House", jsonObject);
				System.out.println(json);

			}

			rs.close();
			sqlConn.commit();
			// System.exit(-1);

			return json;

		} catch (Exception e) {
			e.printStackTrace();
			sqlConn.rollback();
			// System.exit(-1);
			return null;

		} finally {
			if (pt != null)
				try {
					pt.close();
				} catch (SQLException logOrIgnore) {
				}
			if (sqlConn != null)
				try {
					sqlConn.close();
				} catch (SQLException logOrIgnore) {
				}

		}

	}
}
