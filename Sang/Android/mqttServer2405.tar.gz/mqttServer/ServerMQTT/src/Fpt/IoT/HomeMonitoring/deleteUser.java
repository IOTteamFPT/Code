package Fpt.IoT.HomeMonitoring;

import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.eclipse.paho.client.mqttv3.MqttException;

public class deleteUser {
	public java.sql.Connection sqlConn = null;
	public String UserName;
	public int ID;

	public deleteUser() {

	}

	public boolean delete_User(String UserName, int ID) throws SQLException, MqttException {
		DatabaseConnect Conn = new DatabaseConnect();
		sqlConn = Conn.getConnectMysql();
		PreparedStatement pt = null;
		this.UserName = UserName;
		this.ID = ID;
		try {
			sqlConn.setAutoCommit(false);
			String sql = "DELETE FROM Users WHERE UserName = ? AND PassWord = ?";
			pt = sqlConn.prepareStatement(sql);
			pt.setString(1, UserName);
			pt.setInt(2, ID);
			pt.executeUpdate();
			sqlConn.commit();

		} catch (SQLException ex) {
			ex.printStackTrace();

		}

		return true;

	}

}
