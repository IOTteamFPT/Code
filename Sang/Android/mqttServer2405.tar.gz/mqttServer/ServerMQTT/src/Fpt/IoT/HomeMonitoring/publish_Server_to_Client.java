package Fpt.IoT.HomeMonitoring;

import java.sql.Connection;
import java.sql.PreparedStatement;

import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence;

public class publish_Server_to_Client {
	public PreparedStatement statement;
	public Connection sqlConn;
	String topic;
	MqttMessage pub_msg;

	public publish_Server_to_Client() {

	}

	public void publish_Server_to_client(String topic, MqttMessage pub_msg) {
		this.topic = topic;
		this.pub_msg = pub_msg;
		String broker = "tcp://localhost:1883";
		String clientId = MqttClient.generateClientId();

		MemoryPersistence persistence = new MemoryPersistence();
		try {
			final MqttClient Server = new MqttClient(broker, clientId, persistence);
			MqttConnectOptions connOpts = new MqttConnectOptions();
			connOpts.setCleanSession(true);
			Server.connect(connOpts);
			// pub_msg = new MqttMessage();
			Server.publish(topic, pub_msg);
			Server.disconnect();

		} catch (MqttException ex) {
			ex.printStackTrace();

		}

	}

}
