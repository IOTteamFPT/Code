package Fpt.IoT.HomeMonitoring;

import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence;

public class topicPublisher {

	public topicPublisher() {

	}

	public void run() {

		String broker = "tcp://localhost:1883";
		String clientId = MqttClient.generateClientId();
		MemoryPersistence persistence = new MemoryPersistence();
		String topic = "";
		try {
			MqttClient Client = new MqttClient(broker, clientId, persistence);
			MqttConnectOptions connOpts = new MqttConnectOptions();
			connOpts.setCleanSession(true);
			System.out.println("Connect to broker");
			Client.connect(connOpts);
			System.out.println("Connected");
			// Create a Mqtt message
			MqttMessage message = new MqttMessage();
			message.setQos(0);
			System.out.println("publishing message");
			Client.publish(topic, message);

		} catch (MqttException ex) {
			ex.printStackTrace();

		}

	}

}
