package Fpt.IoT.HomeMonitoring;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class registerUser {

	public String UserName;
	public String PassWord;
	public java.sql.Connection sqlConn = null;

	public registerUser() {

	}

	public int register_User(String UserName, String PassWord) throws SQLException {
		DatabaseConnect Conn = new DatabaseConnect();
		sqlConn = Conn.getConnectMysql();

		PreparedStatement pt = null;
		int check_register_user = 1;
		int User_ID = 0;
		ResultSet rs = null;
		String sql;

		this.UserName = UserName;
		this.PassWord = PassWord;

		try {

			sqlConn.setAutoCommit(false);

			sql = "SELECT * FROM Users WHERE(UserName =? AND PassWord =?)";

			pt = sqlConn.prepareStatement(sql);

			pt.setString(1, UserName);
			pt.setString(2, PassWord);

			rs = pt.executeQuery();
			while (rs.next()) {

				String checkUser = rs.getString(2);
				String checkPass = rs.getString(3);

				UserName = rs.getString(2).trim();
				PassWord = rs.getString(3).trim();

				if ((checkUser.equals(UserName) && checkPass.equals(PassWord)) || (UserName).equals(PassWord)) {
					check_register_user = 0;

				}

			}
			sqlConn.commit();
		} catch (SQLException ex) {
			ex.printStackTrace();
			sqlConn.rollback();
			return -1;

		}
		pt.close();
		if (check_register_user == 1) {
			// insert

			sql = "INSERT INTO Users(UserName,PassWord) VALUES(?,?)";
			pt = sqlConn.prepareStatement(sql);
			pt.setString(1, UserName);
			pt.setString(2, PassWord);
			pt.executeUpdate();
			sql = "SELECT ID FROM Users WHERE(UserName =? AND PassWord =?)";
			pt = sqlConn.prepareStatement(sql);
			pt.setString(1, UserName);
			pt.setString(2, PassWord);
			rs = pt.executeQuery();

			while (rs.next()) {
				User_ID = rs.getInt(1);
			}
			sqlConn.commit();
			return User_ID;
		}
		return User_ID;

	}

}
