package Fpt.IoT.HomeMonitoring;

import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.eclipse.paho.client.mqttv3.MqttException;

public class updateUser {

	public java.sql.Connection sqlConn = null;
	String UserName;
	int ID;
	public int rs;

	public updateUser() {

	}

	public boolean update_User(String UserName, int ID) throws MqttException, SQLException {
		DatabaseConnect Conn = new DatabaseConnect();
		sqlConn = Conn.getConnectMysql();

		PreparedStatement pst = null;
		this.UserName = UserName;
		this.ID = ID;
		try {
			sqlConn.setAutoCommit(false);
			String sql = " UPDATE Users " + " SET UserName = ? " + " WHERE ID=?";

			pst = sqlConn.prepareStatement(sql);

			pst.setString(1, UserName);

			pst.setInt(2, ID);

			rs = pst.executeUpdate();

			sqlConn.commit();

		} catch (SQLException ex) {
			ex.printStackTrace();
			sqlConn.rollback();

		}
		return true;

	}

}
