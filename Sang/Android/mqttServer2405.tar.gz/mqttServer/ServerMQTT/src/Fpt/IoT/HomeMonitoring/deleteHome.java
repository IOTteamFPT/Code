package Fpt.IoT.HomeMonitoring;

public class deleteHome {

}
