package Fpt.IoT.HomeMonitoring;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class addHome {
	public java.sql.Connection sqlConn = null;

	public String UserName;
	public String MAC_Add;

	public addHome() {

	}

	public void add_Home(String UserName, String MAC_Add) throws SQLException {

		DatabaseConnect Conn = new DatabaseConnect();
		sqlConn = Conn.getConnectMysql();
		this.UserName = UserName;
		this.MAC_Add = MAC_Add;

		PreparedStatement pt = null;
		ResultSet rs = null;
		ResultSet rs1 = null;
		String sql;

		int User_ID;
		int Home_ID;
		try {

			sqlConn.setAutoCommit(false);
			sql = "SELECT ID FROM Home WHERE(MAC_Add =? )";
			pt = sqlConn.prepareStatement(sql);
			pt.setString(1, MAC_Add);
			rs = pt.executeQuery();
			sql = "SELECT ID FROM Users WHERE(UserName =? )";
			pt = sqlConn.prepareStatement(sql);
			pt.setString(1, UserName);
			rs1 = pt.executeQuery();
			if (rs.next() && rs1.next()) {
				User_ID = rs1.getInt(1);
				Home_ID = rs.getInt(1);
				sql = "INSERT INTO HOME_MANAGE(Home_ID,User_ID) VALUES(?,?)";

				pt = sqlConn.prepareStatement(sql);
				pt.setInt(2, User_ID);
				pt.setInt(1, Home_ID);
				pt.executeUpdate();

			}
			rs.close();
			rs1.close();
			sqlConn.commit();

		} catch (SQLException eX) {
			eX.printStackTrace();

		}

	}

}
