package Fpt.IoT.HomeMonitoring;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.eclipse.paho.client.mqttv3.MqttException;

public class registerHouse {
	public java.sql.Connection sqlConn = null;
	String UserName;
	String PassWord;
	String MAC_Add;

	public registerHouse() {

	}

	public int register_House(String UserName, String PassWord, String MAC_Add) throws MqttException, SQLException {

		DatabaseConnect Conn = new DatabaseConnect();
		sqlConn = Conn.getConnectMysql();
		int check_register_house = 1;
		int Home_ID = 0;
		PreparedStatement pt = null;
		ResultSet rs = null;
		String sql;
		this.UserName = UserName;
		this.MAC_Add = MAC_Add;
		this.PassWord = PassWord;
		try {

			sqlConn.setAutoCommit(false);
			sql = "SELECT * FROM Home WHERE(UserName =? AND PassWord = ? AND MAC_Add =?)";

			pt = sqlConn.prepareStatement(sql);
			pt.setString(1, UserName);
			pt.setString(2, PassWord);
			pt.setString(3, MAC_Add);
			rs = pt.executeQuery();

			while (rs.next()) {

				String checkName = rs.getString(2);

				String checkPASS = rs.getString(3);

				UserName = rs.getString(2).trim();
				PassWord = rs.getString(3).trim();
				// if ((checkUserName.equals(UserName) &&
				// checkPass.equals(PASS)) && ((UserName).equals(PASS))
				// && (checkUserName.equals(UserName)) &&
				// (checkPass.equals(PASS))) {
				if ((checkName.equals(UserName) && checkPASS.equals(PassWord)) || (UserName).equals(PassWord)) {
					check_register_house = 0;

				}

			}
			sqlConn.commit();

		} catch (SQLException ex) {
			ex.printStackTrace();
			sqlConn.rollback();
			return -1;

		}
		pt.close();
		if (check_register_house == 1) {
			// insert

			sql = "INSERT INTO Home(UserName,PassWord,MAC_Add) VALUES(?,?,?)";

			pt = sqlConn.prepareStatement(sql);
			UserName = UserName.split("\"")[3];
			pt.setString(1, UserName);
			PassWord = PassWord.split("\"")[3];
			pt.setString(2, PassWord);
			MAC_Add = MAC_Add.split("\"")[3];
			pt.setString(3, MAC_Add);

			pt.executeUpdate();
			sql = "SELECT ID FROM Home WHERE(UserName =? AND PassWord =?)";
			pt = sqlConn.prepareStatement(sql);
			pt.setString(1, UserName);
			pt.setString(2, PassWord);
			rs = pt.executeQuery();

			/*
			 * while (rs.next()) { Home_ID = rs.getInt(1);
			 * 
			 * sql = "INSERT INTO HOME_MANAGE(Home_ID) VALUES(?)"; pt =
			 * sqlConn.prepareStatement(sql); pt.setInt(1, Home_ID);
			 * pt.executeUpdate();
			 * 
			 * }
			 */
			sqlConn.commit();
		}
		return Home_ID;
	}

}
