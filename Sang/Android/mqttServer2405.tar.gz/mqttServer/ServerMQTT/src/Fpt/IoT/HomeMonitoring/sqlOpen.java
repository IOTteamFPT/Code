package Fpt.IoT.HomeMonitoring;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class sqlOpen {
	public PreparedStatement statement;
	public Connection sqlConn;

	public sqlOpen() {

	}

	/**
	 * Open connection to database SQL server.
	 * 
	 * @return -1 Failed. 0 Success.
	 */
	public int sql_Open(String host, String user, String password) {
		try {
			String myDriver = "org.gjt.mm.mysql.Driver";
			String myUrl = "jdbc:mysql://localhost/REGISTER";
			Class.forName(myDriver);
			sqlConn = DriverManager.getConnection(myUrl, user, password);
		} catch (Exception e) {
			e.printStackTrace();
			return -1;
		}
		return 0;
	}
}
