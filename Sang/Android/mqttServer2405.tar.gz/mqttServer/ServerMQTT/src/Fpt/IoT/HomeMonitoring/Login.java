package Fpt.IoT.HomeMonitoring;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.eclipse.paho.client.mqttv3.MqttException;

public class Login {
	public java.sql.Connection sqlConn = null;

	public String UseName;
	public String PassWord;

	public Login() {

	}

	public int login(String UserName, String PassWord) throws SQLException, MqttException {
		DatabaseConnect Conn = new DatabaseConnect();
		sqlConn = Conn.getConnectMysql();
		this.UseName = UserName;
		this.PassWord = PassWord;
		PreparedStatement pt = null;
		int login_ID = 0;
		ResultSet rs = null;
		try {
			sqlConn.setAutoCommit(false);
			String sql = " SELECT * FROM Users WHERE(UserName = ? AND PassWord = ?)";
			pt = sqlConn.prepareStatement(sql);
			pt.setString(1, UserName);
			pt.setString(2, PassWord);
			rs = pt.executeQuery();

			if (rs.next()) {

				String checkUser = rs.getString(2);
				String checkPass = rs.getString(3);

				UserName = rs.getString("UserName").trim();
				PassWord = rs.getString("PassWord").trim();

				if ((checkUser.equals(UserName) && checkPass.equals(PassWord))) {

					login_ID = rs.getInt(1);
					System.out.println(" Ban da dang nhap thanh cong ");

				}

			}

			else {
				System.out.println("Dang nhap that bai, yeu cau nhap lai ");
				return -1;
			}

			sqlConn.commit();

		} catch (SQLException ex) {

			ex.printStackTrace();
			sqlConn.rollback();

		}
		return login_ID;

	}
}