package Fpt.IoT.HomeMonitoring;

import java.io.Serializable;

public class digitalControl {
	public class digitalCotrol implements Cloneable, Serializable {

		/**
		 * 
		 */
		private static final long serialVersionUID = 1L;
		byte ID;

		byte SubID;
		byte State;

		public digitalCotrol(byte ID, byte SubID, byte State) {
			this.ID = ID;

			this.SubID = SubID;
			this.State = State;

		}
	}
}
