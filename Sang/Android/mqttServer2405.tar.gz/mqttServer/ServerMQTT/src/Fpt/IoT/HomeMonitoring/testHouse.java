package Fpt.IoT.HomeMonitoring;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

public class testHouse {
	public java.sql.Connection sqlConn = null;
	String UserName;
	String PassWord;
	String MAC_Add;

	public testHouse() {

	}

	public int test_House(String UserName, String PassWord, String MAC_Add) throws SQLException, ParseException {
		System.out.println("1");
		registerHomeJson reg = new registerHomeJson();
		DatabaseConnect Conn = new DatabaseConnect();
		sqlConn = Conn.getConnectMysql();
		int check_register_house = 1;
		// int Home_ID = 0;
		PreparedStatement pt = null;
		ResultSet rs = null;
		String sql;
		this.UserName = UserName;
		this.PassWord = PassWord;
		this.MAC_Add = MAC_Add;
		System.out.println("2");

		String jsonString = "{\"USER\": \"sang\" , \"PASS\": \"123\", \"MAC\": \"234\"}";
		// String jsonString = reg.toJSONString();
		// String jsonString = "{\"UserName\": \"1\", \"PassWord\": \"Duy
		// hung\", \"MAC_Add\": \"duyhung.ws@gmail.com\"}";

		try {
			sqlConn.setAutoCommit(false);
			System.out.println("3");

			sql = "SELECT * FROM Home WHERE(UserName =? AND PassWord = ? AND MAC_Add =?)";
			pt = sqlConn.prepareStatement(sql);

			pt.setString(1, UserName);

			pt.setString(2, PassWord);

			pt.setString(3, MAC_Add);
			rs = pt.executeQuery();

			while (rs.next()) {
				System.out.println("6");

				String checkName = rs.getString(2);

				String checkPASS = rs.getString(3);

				UserName = rs.getString(2).trim();
				PassWord = rs.getString(3).trim();
				// if ((checkUserName.equals(UserName) &&
				// checkPass.equals(PASS)) && ((UserName).equals(PASS))
				// && (checkUserName.equals(UserName)) &&
				// (checkPass.equals(PASS))) {
				if ((checkName.equals(UserName) && checkPASS.equals(PassWord)) || (UserName).equals(PassWord)) {
					check_register_house = 0;

				}

			}
			sqlConn.commit();

		} catch (SQLException ex) {
			ex.printStackTrace();

		}
		pt.close();
		if (check_register_house == 1) {
			// insert
			try {
				sql = "INSERT INTO Home(UserName,PassWord,MAC_Add) VALUES(?,?,?)";
				System.out.println(sql);

				pt = sqlConn.prepareStatement(sql);
				JSONParser jsonpare = new JSONParser();
				JSONObject jsonobj = (JSONObject) jsonpare.parse(jsonString);
				UserName = (String) jsonobj.get(UserName);
				UserName = UserName.split("\"")[3];
				System.out.println(UserName);
				pt.setString(1, UserName);
				PassWord = (String) jsonobj.get(PassWord);
				PassWord = PassWord.split("\"")[3];
				pt.setString(2, PassWord);
				MAC_Add = (String) jsonobj.get(MAC_Add);
				MAC_Add = MAC_Add.split("\"")[3];

				pt.setString(3, MAC_Add);
				System.out.println(MAC_Add);

				pt.executeUpdate();

				sqlConn.commit();
			} catch (SQLException ex) {
				ex.printStackTrace();
				sqlConn.rollback();

			} finally {
				if (pt != null)
					try {
						pt.close();
					} catch (SQLException logOrIgnore) {
					}
				if (sqlConn != null)
					try {
						sqlConn.close();
					} catch (SQLException logOrIgnore) {
					}

			}
			sqlConn.close();
		}
		sqlConn.close();
		return 1;
	}

}
