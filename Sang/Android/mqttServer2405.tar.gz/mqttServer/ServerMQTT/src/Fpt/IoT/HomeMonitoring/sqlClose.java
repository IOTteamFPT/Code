package Fpt.IoT.HomeMonitoring;

import java.sql.Connection;
import java.sql.PreparedStatement;

public class sqlClose {
	public PreparedStatement statement;
	public Connection sqlConn;

	public sqlClose() {

	}

	/**
	 * Close connection to database SQL server.
	 * 
	 * @return -1 Failed. 0 Success.
	 */
	public int sql_Close() {
		try {
			sqlConn.close();
		} catch (Exception e) {
			e.printStackTrace();
			return -1;
		}
		return 0;
	}

}
