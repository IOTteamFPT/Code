package Fpt.IoT.HomeMonitoring;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.json.simple.JSONObject;

public class getimforUser {
	public String UserName;
	public java.sql.Connection sqlConn = null;

	public getimforUser() {

	}

	public JSONObject getimfor_User(String UserName) throws SQLException {
		DatabaseConnect Conn = new DatabaseConnect();
		sqlConn = Conn.getConnectMysql();
		PreparedStatement pt = null;
		ResultSet rs = null;
		this.UserName = UserName;
		try {
			sqlConn.setAutoCommit(false);

			String sql = "SELECT  ID,PassWord FROM Users WHERE UserName = ? ";
			pt = sqlConn.prepareStatement(sql);
			pt.setString(1, UserName);
			rs = pt.executeQuery();
			JSONObject jsonObject = new JSONObject();
			JSONObject json = new JSONObject();
			while (rs.next()) {
				int ID = rs.getInt(1);
				String PassWord = rs.getString(2);

				jsonObject.put("ID", ID);
				jsonObject.put("PassWord", PassWord);
				json.put("imformation", jsonObject);
				System.out.println(json);

			}
			rs.close();
			sqlConn.commit();
			return json;

		} catch (SQLException ex) {
			ex.printStackTrace();
			return null;
		}

	}

}
