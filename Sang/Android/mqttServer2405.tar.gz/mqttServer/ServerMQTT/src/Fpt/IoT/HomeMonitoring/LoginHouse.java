package Fpt.IoT.HomeMonitoring;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class LoginHouse {
	public java.sql.Connection sqlConn = null;
	String UserName;
	String PassWord;

	public LoginHouse() {

	}

	public int Login_House(String UserName, String PassWord) throws SQLException {
		DatabaseConnect Conn = new DatabaseConnect();
		sqlConn = Conn.getConnectMysql();
		this.UserName = UserName;
		this.PassWord = PassWord;
		PreparedStatement pt = null;
		int login_ID = 0;
		ResultSet rs = null;
		try {
			sqlConn.setAutoCommit(false);
			String sql = " SELECT * FROM Home WHERE(UserName = ? AND PassWord = ?)";
			pt = sqlConn.prepareStatement(sql);
			System.out.println("UserName:" + UserName);
			UserName = UserName.split("\"")[2];
			pt.setString(1, UserName);
			System.out.println("PassWord:" + PassWord);
			PassWord = PassWord.split("\"")[2];
			pt.setString(2, PassWord);

			// pt = sqlConn.prepareStatement(sql);
			// pt.setString(1, UserName);
			// pt.setString(2, PassWord);
			rs = pt.executeQuery();
			if (rs.next()) {
				System.err.println("22222");

				String checkUser = rs.getString(2);
				String checkPass = rs.getString(3);

				UserName = rs.getString("UserName").trim();
				PassWord = rs.getString("PassWord").trim();
				System.out.println("1111");

				if ((checkUser.equals(UserName) && checkPass.equals(PassWord))) {

					login_ID = rs.getInt(1);
					System.out.println(" Ban da dang nhap thanh cong ");

				}

			}

			else {
				System.out.println("Dang nhap that bai, yeu cau nhap lai ");
				return -1;
			}

			sqlConn.commit();

		} catch (SQLException e) {
			e.printStackTrace();

		}
		return login_ID;

	}
}
