package OptionMain;

import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence;

public class ClientGW {
	public static final String TOPIC_HOUSE_REG = "house/register";
	public static final String TOPIC_HOUSE_UPDATE = "house/update";
	public static final String TOPIC_HOUSE_DELETE = "house/delete";
	public static final String TOPIC_HOUSE_GET = "house/get";


	public ClientGW(){
		
	}
	
	
	 public void run(){
	        String broker       = "tcp://localhost:1883";
	        String clientId    =   MqttClient.generateClientId();
	        MemoryPersistence persistence = new MemoryPersistence();

	        try {
	            final MqttClient sampleClient = new MqttClient(broker, clientId, persistence);
	            MqttConnectOptions connOpts = new MqttConnectOptions();
	            System.out.println("Connecting to broker: "+broker);
	            sampleClient.connect(connOpts);
	            System.out.println("Connected");
	             
	            sampleClient.publish(TOPIC_HOUSE_REG,"REGISTER_HOUSE".getBytes(),0,true);
	            sampleClient.publish(TOPIC_HOUSE_UPDATE,"UPDATE_HOUSE".getBytes(),1,false);
	            sampleClient.publish(TOPIC_HOUSE_DELETE,"DELETE_HOUSE".getBytes(),0,true);
	            sampleClient.publish(TOPIC_HOUSE_GET,"GET_HOUSE".getBytes(),0,true);
	            
	          } catch(MqttException me) {
	            System.out.println("reason "+me.getReasonCode());
	            System.out.println("msg "+me.getMessage());
	            System.out.println("loc "+me.getLocalizedMessage());
	            System.out.println("cause "+me.getCause());
	            System.out.println("excep "+me);
	            me.printStackTrace();
	        }
	    }
}
