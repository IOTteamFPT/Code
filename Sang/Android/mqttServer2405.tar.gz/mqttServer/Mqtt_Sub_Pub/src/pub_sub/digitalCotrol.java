package pub_sub;

import java.io.Serializable;

public class digitalCotrol implements Cloneable, Serializable {

	byte SourceID;
	byte DestID;
	byte SubID;
	byte StateDigital;
	byte Seq_Num;

	public digitalCotrol(byte SourceID, byte DestID, byte SubID, byte StateDigital, byte Seq_Num) {
		this.SourceID = SourceID;
		this.DestID = DestID;
		this.SubID = SubID;
		this.StateDigital = StateDigital;
		this.Seq_Num = Seq_Num;
	};
	////
	//// public void run() {
	//// digitalCotrol dig = null;
	//// dig.SourceID = 0;
	//// dig.DestID = 1;
	//// dig.SubID = 0;
	//// dig.StateDigital = 1;
	//// dig.Seq_Num = 0;
	////
	//// }
	////
}
//
