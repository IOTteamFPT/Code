package topic_House;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class topic_House {
	public static final String TOPIC_HOUSE_REG 		= "house/register";
	public static final String TOPIC_HOUSE_UPDATE   = "house/update";
	public static final String TOPIC_HOUSE_DELETE 	= "house/delete";
	public static final String TOPIC_HOUSE_GET 		= "house/get";
    public  PreparedStatement statement;
    public topic_House(){
    	
    }
    
	/* House register*/
		public  Connection sqlConn;

			 public  void  sqlOpen(String host, String user, String password){
			    	try{
			    	  String myDriver = "org.gjt.mm.mysql.Driver";
			    	  String myUrl = "jdbc:mysql://localhost/REGISTER";
			    	  Class.forName(myDriver);
			    	  
			    	  sqlConn = DriverManager.getConnection(myUrl, user, password);
			    	}
			    	catch (Exception e){
			    		//e.printStackTrace();
			    		//return -1;
			    	}
			    	//return 0;
			    }

		
//////////////////////////////////////////
	
		
		
			 public int sqlClose(){
			    	try{
			    		sqlConn.close();
			    	}catch (Exception e){
			    		//e.printStackTrace();
			    		return -1;
			    	}
			    	return 0;
			 }
			    	
			    	    
		
	////////////////////////////////

		

			public int sqlCreateTable(String table){
		    	try{
			    	Statement st = sqlConn.createStatement();
				      
			    	String sql = "CREATE TABLE " + table + " " +
								 "(ID INTEGER not NULL, " +
								 " UserName VARCHAR(255), " + 
								 " PassWord VARCHAR(255), " +
								 " MAC_Add VARCHAR(255), " +
								 " PRIMARY KEY ( ID ))";
		    		st.executeUpdate(sql);
		    	}
		    	catch (Exception e){
		    		e.printStackTrace();
		      	  	return -1;
		      	}

		    	return 0;
		    }			

	////////////////////////////
	
		 public int sqlRemoveTable(String table){
		    	
		    	return 0;
		    }

	
	////////////////////////////////
	
		
			 public void sqlTableAddRow(String table, String[] data){
			    	try{
				    	Statement st = sqlConn.createStatement();
						String sql = " INSERT INTO " + table +" VALUES(?,?,?,?)";
						
						PreparedStatement pt = sqlConn.prepareStatement(sql);
						pt.setInt(1, Integer.parseInt(data[0]));
						pt.setString(2, data[1]);
						pt.setString(3, data[2]);
						pt.setString(4, data[3]);
						pt.executeUpdate();
						
						st.executeUpdate(sql);
						
			    	}
			    	catch (Exception e){
			    		//e.printStackTrace();
			      	  	//return -1;
			      	}		
			    	//return 0;
			    }

		
	///////////////////////////////
	
		public void sqlTableRemoveRow(String MAC_Add) throws SQLException{
	    	PreparedStatement pst = null;
	    	sqlConn.setAutoCommit(false);
	    	try{
	    		String sql = "DELETE FROM Register_House " +
	    					 "WHERE MAC_Add = ?";
	    		
	    		pst = sqlConn.prepareStatement(sql);
	    		pst.setString(1,MAC_Add);
	    		pst.executeUpdate();
	    		sqlConn.commit();
	    		
	    	} catch(SQLException ex){
	    		sqlConn.rollback();
	    		throw ex;
	    		
	    	}
	    	
	    }
	    
	
	///////////////////////////////////////
	
		public boolean updateData(String userName, String passWord, String MacAddr) throws SQLException {
		    //public void updateData(String userName, String passWord, String MacAddr) throws SQLException {
				
		    	PreparedStatement pst = null;
		    	sqlConn.setAutoCommit(false);
		    	try {
		    		String sql = 
		    				" UPDATE Register_House " +
		    				" SET UserName = ?' ," +
		    				" PassWord = ? " +
		    				" WHERE MAC_Add = ?";
					pst = sqlConn.prepareStatement(sql);
					pst.setString(1, userName);
					pst.setString(2, passWord);
					pst.setString(3, MacAddr);
					pst.executeUpdate();
					
					sqlConn.commit();
					return true;
		    		
		    	}catch(SQLException ex) {
		    		sqlConn.rollback();
		    		return false;
		   		//throw ex;
		    		
		    	} finally {
					if (pst != null) pst.close();
				} 	
		    		
			}

	//////////////////////////////////
	
		public int getIm( String UserName) throws SQLException{
	    	try{
	    		PreparedStatement pst = null;
	    		ResultSet rs = null;
	        	sqlConn.setAutoCommit(false);
	        	//String sql = 'SELECT PassWord, MAC_Add FROM Register_House WHERE UserName = ? ';
	        	String sql = "SELECT  PassWord, MAC_Add FROM Register_House WHERE UserName = ? ";
	        	pst = sqlConn.prepareStatement(sql);
	        	pst.setString(1,UserName);
	        	rs = pst.executeQuery();
	        	
	        	while(rs.next()) {
	        		String MAC_Add = rs.getString("MAC_Add");
	        		String PassWord = rs.getString("PassWord");
	        		
	        		System.out.println("MAC_Add :" + MAC_Add);
	        		System.out.println("PassWord :" + PassWord);
	        	}
	        	rs.close();
				sqlConn.commit();
				
	    	}catch(SQLException ex){
	    		sqlConn.rollback();
	    		throw ex;
	    	}
	    	return 0;
	    	
	    }
	    

	}

