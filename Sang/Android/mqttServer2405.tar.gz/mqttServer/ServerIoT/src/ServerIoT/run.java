package ServerIoT;
import java.sql.PreparedStatement;

import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence;

import topic_House.topic_House;

public class run {
	public static final String TOPIC_HOUSE_REG 		= "house/register";
	public static final String TOPIC_HOUSE_UPDATE   = "house/update";
	public static final String TOPIC_HOUSE_DELETE 	= "house/delete";
	public static final String TOPIC_HOUSE_GET 		= "house/get";
    public  PreparedStatement statement;
    int rs = 0;
    int id_counter = 0;
	

	public static void main(String[] args) {
		
       run Iot = new run();
       Iot.main();
	}
	public run(){
		
	}
	
	
	public void  main(){
		 String broker       = "tcp://localhost:1883";
	     String clientId    =   MqttClient.generateClientId();
	     MemoryPersistence persistence = new MemoryPersistence();
		topic_House opt = new topic_House();
		opt.sqlOpen("localhost", "root", "");
		
		try {
            final MqttClient sampleClient = new MqttClient(broker, clientId, persistence);
            MqttConnectOptions connOpts = new MqttConnectOptions();
            System.out.println("Connecting to broker: "+broker);
            sampleClient.connect(connOpts);
            System.out.println("Connected");
           
            /*----------------GOI HAM CALLBACK---------------------*/
             sampleClient.setCallback(new MqttCallback() { 
           
            	    public void connectionLost(Throwable cause) { 
            	     System.out.println("connectionLost-----------1" + cause); 
            	    } 
            	    public void deliveryComplete(IMqttDeliveryToken token) { 
            	     System.out.println("deliveryComplete---------2" + token.isComplete()); 
            	    } 
            	    public void messageArrived(String topic, MqttMessage arg1) 
            	      throws Exception { 
            	     System.out.println("messageArrived----------3"+topic+"  "+arg1.toString());
            	     
            	     switch(topic){
            	     /*Dang ky them nha moi 
            	      * ID House duoc Server cap tu dong
            	      * Du lieu data gom UserName,passWord, MAC_Add
            	      * */
        	    	 case TOPIC_HOUSE_REG:
        	    		 System.out.println("->register house :" + arg1);
        	    		 
        	    		 String[] data = arg1.toString().split(";");
        	    		 
        	    		 if(data.length <3 )
        	    			 break;
        	    		 
        	    		 String[] datas = new String[(data.length) +1];
        	    		 
        	    		 datas[0] = Integer.toString(id_counter++);
        	    		 
        	    		 for(int i = 0; i < data.length; i++){
        	    			 datas[i+1] = data[i];
        	    		 
        	    		 }
        	    	       
        	    		 //mqttDao.sqlCreateTable("Register_House");
        	    		   //sqlTableAddRow("HouseReg", new String[]{"1", "Name", "Tuan", "String"});
        	    		  //sqlTableAddRow("HouseReg", new String[]{"2", "Year", "2011", "Integer"});
        	    		 // sqlTableAddRow("HouseReg", new String[]{"3", "Price", "100 mil", "String"});
        	    		  opt.sqlTableAddRow("Register_House", datas);
        	    		  System.out.println("Register success");
        	    		 
        	    		 break;
        	    		 /* Update  lai du lieu vao Database
        	    		  * UserName,PassWord update du lieu moi dua vao dia chi MAC cua GateWay
        	    		    */
        	    	 case TOPIC_HOUSE_UPDATE:
        	    		 System.out.println("->update house:" + arg1);
        	    		 
        	    		 String[] dataRetrieve = arg1.toString().split(";");
        	    		 
        	    		 if (dataRetrieve.length <3 ) break;
        	    		 //System.out.println(dataRetrieve);
        	    		 
        	    		 boolean flg = opt.updateData(dataRetrieve[0], dataRetrieve[1], dataRetrieve[2]);
        	    		 //mqttDao.updateData(dataRetrieve[0], dataRetrieve[1], dataRetrieve[2]);
//        	    		 
        	    		 if (flg == true){
      	    			 rs = 1;//update ok
       	    		      }
        	    		 System.out.println("Lan 1");
        	    		 break;
//        	    	 case TOPIC_HOUSE_DELETE:
//        	    		 System.out.println("->delete house :" + arg1);
//        	    		 String[] data_del =arg1.toString().split(";"); 
//        	    		 if (data_del.length < 3) break;
//        	    		 System.out.println(data_del);
//        	    		 mqttDao.sqlTableRemoveRow(data_del[0]);
//        	    		 System.out.println("Delete Success");
//        	    		 
////        	    		 break;
        	    	 case TOPIC_HOUSE_GET:
        	    		 System.out.println("get house:" + arg1);
        	    		 String dataget = arg1.toString();
        	    		 //int id1 = Integer.parseInt(dataget[0]);
        	    		 //if (dataget.length > 3) break;
        	    		 //System.out.println(dataget[2]);
        	    		 //System.out.println(dataget[1]);
//        	    		 mqttDao.getIm(dataget[1]);
        	    		 opt.getIm(dataget);
        	    		 System.out.println("Get success");
        	    		 break;
        	    	 default:
        	    		 break;
        	    	 
        	    	 }
            	    }
					
					
            	   });
  
            sampleClient.subscribe(TOPIC_HOUSE_REG);
            sampleClient.subscribe(TOPIC_HOUSE_UPDATE);
            sampleClient.subscribe(TOPIC_HOUSE_DELETE);
            sampleClient.subscribe(TOPIC_HOUSE_GET);
        } catch(MqttException me) {
            System.out.println("reason "+me.getReasonCode());
            System.out.println("msg "+me.getMessage());
            System.out.println("loc "+me.getLocalizedMessage());
            System.out.println("cause "+me.getCause());
            System.out.println("excep "+me);
           // me.printStackTrace();
        }
        //opt.sqlClose();
        
        // Disconnect to database server
        //mqttDao.sqlClose();
	}
	
}

