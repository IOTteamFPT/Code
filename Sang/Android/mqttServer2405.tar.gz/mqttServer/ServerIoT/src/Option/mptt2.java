package Option;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence;

public class mptt2 {
	public static final String TOPIC_HOUSE_REG 		= "house/register";
	public static final String TOPIC_HOUSE_UPDATE   = "house/update";
	public static final String TOPIC_HOUSE_DELETE 	= "house/delete";
	public static final String TOPIC_HOUSE_GET 		= "house/get";
    public  PreparedStatement statement;
    private Connection sqlConn;
    
    private int id_counter = 10;

    public static void main(String[] args) {

    	mptt2 mqtt = new mptt2();
    	mqtt.run();
    }
    
    public mptt2(){	        
    }
    
    public void run(){
        String broker       = "tcp://localhost:1883";
        String clientId    =   MqttClient.generateClientId();
        
   
        // Open connection to database server
        sqlOpen("localhost","root", "");
        MemoryPersistence persistence = new MemoryPersistence();

        try {
            final MqttClient sampleClient = new MqttClient(broker, clientId, persistence);
            MqttConnectOptions connOpts = new MqttConnectOptions();
            System.out.println("Connecting to broker: "+broker);
            sampleClient.connect(connOpts);
            System.out.println("Connected");
           
            /*----------------GOI HAM CALLBACK---------------------*/
             sampleClient.setCallback(new MqttCallback() { 
           
            	    public void connectionLost(Throwable cause) { 
            	     System.out.println("connectionLost-----------" + cause); 
            	    } 
            	    public void deliveryComplete(IMqttDeliveryToken token) { 
            	     System.out.println("deliveryComplete---------" + token.isComplete()); 
            	    } 
            	    public void messageArrived(String topic, MqttMessage arg1) 
            	      throws Exception { 
            	     System.out.println("messageArrived----------"+topic+" arg "+arg1.toString());
            	     
            	     switch(topic){
        	    	 case TOPIC_HOUSE_REG:
        	    		 System.out.println("->register house :" + arg1);
        	    		 
        	    		 String[] data = arg1.toString().split(";");
        	    		 
        	    		 if(data.length < 3)
        	    			 break;
        	    		 
        	    		 String[] datas = new String[(data.length) +1];
        	    		 
        	    		 datas[0] = Integer.toString(id_counter++);
        	    		 
        	    		 for(int i = 0; i < data.length; i++){
        	    			 datas[i+1] = data[i];
        	    		 
        	    		 }
        	    	       
        	    	       // sqlCreateTable("Register_House");
        	    		   //sqlTableAddRow("HouseReg", new String[]{"1", "Name", "Tuan", "String"});
        	    		  //sqlTableAddRow("HouseReg", new String[]{"2", "Year", "2011", "Integer"});
        	    		 // sqlTableAddRow("HouseReg", new String[]{"3", "Price", "100 mil", "String"});
        	    		   sqlTableAddRow("Register_House", datas);
        	    		 
        	    		 break;
        	    	 case TOPIC_HOUSE_UPDATE:
        	    		 System.out.println("->update house:" + arg1);
        	    		 
        	    		 String[] dataRetrieve = arg1.toString().split(";");
        	    		 if (dataRetrieve.length < 3) break;
        	    		 
        	    		 updateData(dataRetrieve[0], dataRetrieve[1], dataRetrieve[2]);
        	    		 System.out.println("Update Success");
        	    		 
        	    		 break;
        	    	 case TOPIC_HOUSE_DELETE:
        	    		 System.out.println("->delete house :" + arg1);
        	    		 break;
        	    	 case TOPIC_HOUSE_GET:
        	    		 System.out.println("get house:" + arg1);
        	    		 String[] dataget = arg1.toString().split(";");
        	    		 if (dataget.length < 3) break;
        	    		 Getim(dataget[0]);
        	    		 System.out.println("Get success");
        	    		  
        	    		 break;
        	    	 default:
        	    		 break;
        	    	 
        	    	 }
            	    } 
            	   });
  
            sampleClient.subscribe(TOPIC_HOUSE_REG);
            sampleClient.subscribe(TOPIC_HOUSE_UPDATE);
            sampleClient.subscribe(TOPIC_HOUSE_DELETE);
            sampleClient.subscribe(TOPIC_HOUSE_GET);
        } catch(MqttException me) {
            System.out.println("reason "+me.getReasonCode());
            System.out.println("msg "+me.getMessage());
            System.out.println("loc "+me.getLocalizedMessage());
            System.out.println("cause "+me.getCause());
            System.out.println("excep "+me);
            me.printStackTrace();
        }
        
        // Disconnect to database server
        //sqlClose();
    } 
    
    /**
     * Open connection to database SQL server.
     * 
     * House-Tuan
     * 		id 		key 		value		type
     * 		12		name		Tuan 		String
     * 		13 		year 		2015 		Integer
     * 
     * @return
     * 		-1 Failed.
     * 	 	 0 Success.
     */
    public int sqlOpen(String host, String user, String password){
    	try{
    	  String myDriver = "org.gjt.mm.mysql.Driver";
    	  String myUrl = "jdbc:mysql://localhost/REGISTER";
    	  Class.forName(myDriver);
    	  
    	  sqlConn = DriverManager.getConnection(myUrl, user, password);
    	}
    	catch (Exception e){
    		e.printStackTrace();
    		return -1;
    	}
    	return 0;
    }
    
    /**
     * Close connection to database SQL server.
     * @return
     * 		-1 Failed.
     * 	 	 0 Success.
     */
    public int sqlClose(){
    	try{
    		sqlConn.close();
    	}
    	catch (Exception e){
    		//e.printStackTrace();
    		return -1;
    	}
    	return 0;
    }
    
    /**
     * Create a new table on SQL server.
     * @return
     * 		-1 Failed.
     * 	 	 0 Success.
     */
    public int sqlCreateTable(String table){
    	try{
	    	Statement st = sqlConn.createStatement();
		      
	    	String sql = "CREATE TABLE " + table + " " +
						 "(ID INTEGER not NULL, " +
						 " UserName VARCHAR(255), " + 
						 " PassWord VARCHAR(255), " +
						 " MAC_Add VARCHAR(255), " +
						 " PRIMARY KEY ( ID ))";
    		st.executeUpdate(sql);
    	}
    	catch (Exception e){
    		//e.printStackTrace();
      	  	return -1;
      	}

    	return 0;
    }
    
    /**
     * Remove a table from database on SQL server.
     * @return
     * 		-1 Failed.
     * 	 	 0 Success.
     */
    public int sqlRemoveTable(String table){
    	

    	return 0;
    }
    
    /**
     * Add a new row of data to existing table on SQL server.
     * @return
     * 		-1 Failed.
     * 	 	>0 Row ID.
     */
    public int sqlTableAddRow(String table, String[] data){
    	try{
	    	Statement st = sqlConn.createStatement();
			String sql = "INSERT INTO " + table +" VALUES(?,?,?,?)";
			
			PreparedStatement pt = sqlConn.prepareStatement(sql);
			pt.setInt(1, Integer.parseInt(data[0]));
			pt.setString(2, data[1]);
			pt.setString(3, data[2]);
			pt.setString(4, data[3]);
			pt.executeUpdate();
			
			st.executeUpdate(sql);
    	}
    	catch (Exception e){
    		//e.printStackTrace();
      	  	return -1;
      	}		
    	return 0;
    }

    /**
     * Remove a row of data from existing table on SQL server.
     * @return
     * 		-1 Failed.
     * 	 	 0 Success.
     */
    public int sqlTableRemoveRow(String table, int id){
    	
    	//"DELETE FROM TABLE WHERE id = ID";
    	return 0;
    }
    
    public void updateData(String userName, String passWord, String MacAddr) throws SQLException {
		
    	PreparedStatement pst = null;
    	sqlConn.setAutoCommit(false);
    	try {
    		String sql = 
    				" UPDATE Register_House " +
    				" SET UserName = ? ," +
    				" PassWord = ? " +
    				" WHERE MAC_Add = ?";
    					System.out.println(sql);	
			pst = sqlConn.prepareStatement(sql);
			pst.setString(1, userName);
			pst.setString(2, passWord);
			pst.setString(3, MacAddr);
			
			pst.executeUpdate();
			
			sqlConn.commit();
    		
    	}catch(SQLException ex) {
    		sqlConn.rollback();
    		throw ex;
    	} finally {
			if (pst != null) pst.close();
		} 	

	}
    public String Getim(String MAC_Add) throws SQLException{
    	try{
    		PreparedStatement pst = null;
    		ResultSet rs = null;
        	sqlConn.setAutoCommit(false);
        	String sql = "SELECT ID = ? FROM Register_House WHERE MAC_Add = ? ";
        	pst = sqlConn.prepareStatement(sql);
        	pst.setString(1, MAC_Add);
        	rs = pst.executeQuery();
        	
        	String id = "";
        	if(rs.next()) {
        		id = rs.getString("ID");
        	}
			sqlConn.commit();
    		return id;
    	}catch(SQLException ex){
    		sqlConn.rollback();
    		throw ex;
    	}
    	
    	
    }
}
