package IoTFuncOpt;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class IoTFuncOpt {
	public static final String TOPIC_HOUSE_REG = "house/register";
	public static final String TOPIC_HOUSE_UPDATE = "house/update";
	public static final String TOPIC_HOUSE_DELETE = "house/delete";
	public static final String TOPIC_HOUSE_GET = "house/get";
	public PreparedStatement statement;
	public Connection sqlConn;

	public IoTFuncOpt() {

	}

	public int sqlOpen(String host, String user, String password) {
		try {
			String myDriver = "org.gjt.mm.mysql.Driver";
			String myUrl = "jdbc:mysql://localhost/REGISTER";
			Class.forName(myDriver);
			sqlConn = DriverManager.getConnection(myUrl, user, password);
		} catch (Exception e) {
			e.printStackTrace();
			return -1;
		}
		return 0;
	}

	/**
	 * Close connection to database SQL server.
	 * 
	 * @return -1 Failed. 0 Success.
	 */
	public int sqlClose() {
		try {
			sqlConn.close();
		} catch (Exception e) {
			e.printStackTrace();
			return -1;
		}
		return 0;
	}

	public int Login(String UserName, String PassWord) throws SQLException {
		ResultSet rs = null;
		int ID = 0;
		try {
			PreparedStatement pst = null;
			sqlConn.setAutoCommit(false);
			String sql = " SELECT * FROM Users WHERE UserName = ? AND PassWord = ? ";
			pst = sqlConn.prepareStatement(sql);
			pst.setString(1, UserName);
			pst.setString(2, PassWord);
			rs = pst.executeQuery();

			if (rs.next()) {
				String checkUser = rs.getString(1);
				String checkPass = rs.getString(2);
				PassWord = rs.getString("PassWord").trim();
				if ((checkUser.equals(UserName) && checkPass.equals(PassWord))) {
					System.out.println("Thành công");
				} else {
					System.out.println("Fail");
				}
				sqlConn.commit();

			} else {
				System.out.println("That bai");
				return -1;
			}

		} catch (SQLException ex) {
			ex.printStackTrace();
			sqlConn.rollback();

		}
		return ID;

	}

	/*
	 * Register House
	 * 
	 * @return -1 Fail
	 * 
	 * @return ID House
	 */
	public int Register_User(String UserName, String PassWord) throws SQLException {
		// System.out.println(UserName);
		// System.out.println(PassWord);
		PreparedStatement pt = null;
		int ID = 0;
		ResultSet rs = null;
		try {
			sqlConn.setAutoCommit(false);

			String sql = "INSERT INTO Users(UserName,PassWord) VALUES(?,?)";
			pt = sqlConn.prepareStatement(sql);
			pt.setString(1, UserName);
			pt.setString(2, PassWord);
			pt.executeUpdate();
			sql = "SELECT ID FROM Users WHERE(UserName =? AND PassWord =?)";
			pt = sqlConn.prepareStatement(sql);
			pt.setString(1, UserName);
			pt.setString(2, PassWord);
			rs = pt.executeQuery();

			while (rs.next()) {
				ID = rs.getInt("ID");

			}
			sqlConn.commit();

		} catch (SQLException ex) {
			ex.printStackTrace();
			sqlConn.rollback();
			return -1;
		}
		pt.close();
		// System.out.println(ID);

		return ID;
	}

}
