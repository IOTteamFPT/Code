package IoTClientGW;

import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence;

public class IoTClientGW {
	public static final String TOPIC_HOUSE_REG = "house/register";
	public static final String TOPIC_USER_REG = "house/user";
	public static final String TOPIC_HOUSE_UPDATE = "house/update";
	public static final String TOPIC_HOUSE_DELETE = "house/delete";
	public static final String TOPIC_HOUSE_GET = "house/get";
	public static final String TOPIC_HOUSE_LOGIN = "house/login";

	public IoTClientGW() {
	}

	public void run() {
		String broker = "tcp://localhost:1883";
		String clientId = MqttClient.generateClientId();
		MemoryPersistence persistence = new MemoryPersistence();
		try {
			final MqttClient sampleClient = new MqttClient(broker, clientId, persistence);
			MqttConnectOptions connOpts = new MqttConnectOptions();
			System.out.println("Connecting to broker: " + broker);
			sampleClient.connect(connOpts);
			System.out.println("Connected");

			sampleClient.publish(TOPIC_HOUSE_REG, "REGISTER_HOUSE".getBytes(), 2, true);
			sampleClient.publish(TOPIC_HOUSE_UPDATE, "UPDATE_HOUSE".getBytes(), 2, true);
			sampleClient.publish(TOPIC_HOUSE_DELETE, "DELETE_HOUSE".getBytes(), 2, true);
			sampleClient.publish(TOPIC_HOUSE_GET, "GET_HOUSE".getBytes(), 2, true);

			// Generate random number here

			sampleClient.publish(TOPIC_USER_REG, "USER".getBytes(), 2, true);
			// sampleClient.subscribe(TOPIC_USER_REG);
			// sampleClient.publish(TOPIC_USER_REG, "LOGIN_USER".getBytes(), 2,
			// true);

			// subcribe event
			// sampleClient.setCallback(new MqttCallback() {
			//
			// public void connectionLost(Throwable cause) {
			// System.out.println("connectionLost-----------1" + cause);
			// }
			//
			// public void deliveryComplete(IMqttDeliveryToken token) {
			// System.out.println("deliveryComplete---------2" +
			// token.isComplete());
			// }
			//
			// public void messageArrived(String topic, MqttMessage arg1) throws
			// Exception {
			// System.out.println("messageArrived----------3 " + topic + " " +
			// arg1.toString());
			//
			// // TODO: process login status here.
			// // if (topic.equals(TOPIC_USER_REG)) {
			// // // CHECK STATUS IS OK OR ERROR
			// // sampleClient.subscribe(TOPIC_USER_REG);
			// // }
			// }
			// });

		} catch (MqttException me) {
			System.out.println("reason " + me.getReasonCode());
			System.out.println("msg " + me.getMessage());
			System.out.println("loc " + me.getLocalizedMessage());
			System.out.println("cause " + me.getCause());
			System.out.println("excep " + me);
			me.printStackTrace();
		}

	}

}
