package com.fsoft.smarthome.adapter;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.ToggleButton;

import com.fsoft.smarthome.R;
import com.fsoft.smarthome.dao.Device;
import com.fsoft.smarthome.listenner.StateChangeListenner;

import java.util.ArrayList;

/**
 * Created by HoangBVN on 5/12/2017.
 */

public class DeviceAdapter extends BaseAdapter {

    private ArrayList<Device> data;
    private Activity activity;
    private StateChangeListenner listenner;

    private class Holder

    {
        private ImageView icon;
        private TextView name;
        private ToggleButton status;
        private Device device;

        public void update() {
            name.setText(device.getName());
            status.setChecked(device.getStatus() == 1);
            if (device.getType() == 0) {
                icon.setImageResource(R.mipmap.ic_light);
            } else if (device.getType() == 1) {
                icon.setImageResource(R.mipmap.ic_tivi);
            } else if (device.getType() == 2) {
                icon.setImageResource(R.mipmap.ic_fan);
            } else if (device.getType() == 3) {
                icon.setImageResource(R.mipmap.ic_air);
            } else if (device.getType() == 4) {
                icon.setImageResource(R.mipmap.ic_fridge);
            }
        }

        public ImageView getIcon() {
            return icon;
        }

        public void setIcon(ImageView icon) {
            this.icon = icon;
        }

        public TextView getName() {
            return name;
        }

        public void setName(TextView name) {
            this.name = name;
        }

        public ToggleButton getStatus() {
            return status;
        }

        public void setStatus(ToggleButton status) {
            this.status = status;
        }

        public Device getDevice() {
            return device;
        }

        public void setDevice(Device device) {
            this.device = device;
        }
    }

    public DeviceAdapter(Activity activity, ArrayList<Device> data, StateChangeListenner listenner) {
        this.activity = activity;
        this.data = data;
        this.listenner = listenner;
    }

    @Override
    public int getCount() {
        return data.size();
    }

    @Override
    public Object getItem(int position) {
        return data.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        View view = convertView;
        if (convertView == null) {
            LayoutInflater inflater = (LayoutInflater) activity.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            view = inflater.inflate(R.layout.listview_device, null);
        }
        Holder holder = new Holder();
        ImageView icon = (ImageView) view.findViewById(R.id.icon);
        holder.setIcon(icon);
        TextView name = (TextView) view.findViewById(R.id.name);
        holder.setName(name);
        final ToggleButton status = (ToggleButton) view.findViewById(R.id.status);
        status.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (status.isChecked()) {
//                    data.get(position).setStatus(1);
                    listenner.onStateOn(data.get(position).getType());
                } else {
//                    data.get(position).setStatus(0);
                    listenner.onStateOff(data.get(position).getType());
                }
            }
        });
        holder.setStatus(status);
        holder.setDevice(data.get(position));
        holder.update();
        if (data.get(position).getStatus() == 1) {
            view.setBackgroundColor(activity.getResources().getColor(R.color.colorON));
            status.setChecked(true);
        } else {
            view.setBackgroundColor(activity.getResources().getColor(R.color.colorOFF));
            status.setChecked(false);
        }
        return view;
    }
}
