package com.fsoft.smarthome.activity;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;

import com.fsoft.smarthome.R;
import com.fsoft.smarthome.controller.ClientPublishController;
import com.fsoft.smarthome.listenner.ConnectionListenner;
import com.fsoft.smarthome.service.MQTTServiceSimple;

import static com.fsoft.smarthome.constant.Define.APP_ID;
import static com.fsoft.smarthome.constant.Define.MQTT_BROKER;
import static com.fsoft.smarthome.constant.Define.MQTT_TOPIC;

public class StartActivity extends Activity implements ConnectionListenner {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_start);
        SharedPreferences settings = getSharedPreferences(APP_ID, 0);
        SharedPreferences.Editor editor = settings.edit();
        editor.putString("broker", MQTT_BROKER); // CHANGE ME to your broker address
        editor.putString("topic", MQTT_TOPIC); // CHANGE ME to your topic
        editor.commit();
        new Handler().post(new Runnable() {
            @Override
            public void run() {
                creatConnection();
            }
        });
        Intent svc = new Intent(this, MQTTServiceSimple.class);
        startService(svc);
    }

    protected void creatConnection() {
        ClientPublishController.getInstance().connect(this);
    }

    protected void changeScreen() {
        //Intent intent = new Intent(this,RegisterActivity.class);
        Intent intent = new Intent(this, LoginActivity.class);
        startActivity(intent);
        finish();
    }

    @Override
    public void onSuccess() {
        ClientPublishController.getInstance().publishMessage("connected successfull");
        changeScreen();
    }

    @Override
    public void onFailure() {

    }
}
