package com.fsoft.smarthome.activity;

import android.app.Application;

/**
 * Created by HoangBVN on 5/12/2017.
 */

public class SHApplication extends Application {
    private static SHApplication singleton;

    /**
     * Get single instance of SHApplication - a sub-class of Application which is instantiated
     * before any other class when the process for your application/package is created.
     *
     * @return single instance of SHApplication for maintaining global application state.
     */
    public static SHApplication getInstance() {
        return singleton;
    }

    /**
     * Called when the application is starting, before any activity, service, or receiver objects
     * (excluding content providers) have been created.
     */
    @Override
    public void onCreate() {
        super.onCreate();
        singleton = this;
    }
}
