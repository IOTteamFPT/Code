package com.fsoft.smarthome.listenner;

/**
 * Created by HoangBVN on 5/12/2017.
 */

public interface ConnectionListenner {
    void onSuccess();

    void onFailure();
}
