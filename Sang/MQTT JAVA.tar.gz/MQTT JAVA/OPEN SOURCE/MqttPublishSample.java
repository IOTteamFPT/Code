package MqttPublishSample;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Date;

import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence;

public class MqttPublishSample {

    public static void main(String[] args) {

    	MqttPublishSample mqtt = new MqttPublishSample();
    	
    	mqtt.run();
    	mqtt.dbOpen("localhost", "root", "");
    }
    
    public MqttPublishSample(){
    	        
    }
    
    public void run(){
    	String topic        = "default";
    	
        final String content      = "Message from MqttPublishSample Server";
        int qos             = 1;
        byte [] payload  ;
        boolean retained = true; 
        String broker       = "tcp://localhost:1883";
        String  userName    = " userName";
        String  password    =  "passWord";
        String clientId    =   MqttClient.generateClientId();
   
        MemoryPersistence persistence = new MemoryPersistence();

        try {
            final MqttClient sampleClient = new MqttClient(broker, clientId, persistence);
            MqttConnectOptions connOpts = new MqttConnectOptions();
            connOpts.setCleanSession(true);
            connOpts.setUserName(userName);	 
            connOpts.setPassword(password.toCharArray());
            connOpts.setKeepAliveInterval(60000);
            System.out.println("Connecting to broker: "+broker);
            sampleClient.connect(connOpts);
            System.out.println("Connected");
           
            /*----------------GOI HAM CALLBACK---------------------*/
            //System.out.println("Publishing message: "+content);
             sampleClient.setCallback(new MqttCallback() { 
            	 
            	    @Override 
            	    public void connectionLost(Throwable cause) { 
            	     System.out.println("connectionLost-----------"); 
            	    } 
            	 
            	    @Override 
            	    public void deliveryComplete(IMqttDeliveryToken token) { 
            	     System.out.println("deliveryComplete---------" 
            	       + token.isComplete()); 
            	    } 
            	 
            	    @Override 
            	    public void messageArrived(String topic, MqttMessage arg1) 
            	      throws Exception { 
            	     System.out.println("messageArrived----------"+topic+" arg "+arg1.toString());
            	     if(arg1.toString().contains("2")){

            	    	 MqttMessage message = new MqttMessage(content.getBytes());
            	            
            	            sampleClient.publish(topic, message);
            	            //xulymassage()
            	     }
            	 
            	    } 
            	   });
            //MqttMessage message = new MqttMessage(content.getBytes());
            //message.setQos(qos);
            
            //message.setRetained(retained);
            //sampleClient.publish(topic, message);
            sampleClient.subscribe(topic);
            
            //System.out.println("Message published");
            
            //System.out.println("Disconnected");
            //System.exit(0);
        } 
        catch(MqttException me) {
            System.out.println("reason "+me.getReasonCode());
            System.out.println("msg "+me.getMessage());
            System.out.println("loc "+me.getLocalizedMessage());
            System.out.println("cause "+me.getCause());
            System.out.println("excep "+me);
            me.printStackTrace();
        }
    }
    //xulymassage(){
    //kiem tra massage
    //dangkiuser();
    //}
    /*-----------------GUI DU LIEU------------------------*/
    public void sendData(String data){
    	
    	
    }
    
    
    
    /*--------TAO DATABASE VOI MYSQL -----------------*/
    public int dbOpen(String host, String user, String password){
    	try
    	{
    	  // create a java mysql database connection
    	  String myDriver = "org.gjt.mm.mysql.Driver";
    	  String myUrl = "jdbc:mysql://localhost/DeviceMange";
    	  Class.forName(myDriver);
    	  Connection conn = DriverManager.getConnection(myUrl, user, password);

    	  // your prepstatements goes here...
    	  
    	  
    	  System.err.println("Connect to db success! ");

    	  conn.close();
    	}
    	catch (Exception e)
    	{
    	  System.err.println("Got an exception! ");
    	  System.err.println(e.getMessage());
    	  return -1;
    	}
    	return 0;
    }
}