
package MqttPublishSample;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Date;
import java.util.concurrent.TimeUnit;


import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class MqttPublishSample {

	public static final String TOPIC_HOUSE_REG 		= "/house/register";
	public static final String TOPIC_HOUSE_UPDATE   = "/house/update";
	public static final String TOPIC_HOUSE_REMOVE   = "/house/remove";
	public static final String TOPIC_HOUSE_GET 		= "/house/get";
	/*-------------JDBC DATABASE-----*/
	public static final String JDBC_URL = "jdbc:mysql://localhost:1883/mqtt_DeviceMange?user=root&password= ";

	public static final String SQL_INSERT = "INSERT INTO `User` (`userName`,`ID`,`passWord`) VALUES (?,?,?)";
	public  PreparedStatement pst;
	
    /*-----------------HAM MAIN-----------*/
    public static void main(String[] args) {

        MqttPublishSample mqtt = new MqttPublishSample();
        
        mqtt.run();
        mqtt.dbOpen("localhost", "root", "");
    }
    
    public MqttPublishSample(){
                
    }
    
    public void run(){
        String topic       ;
        final String content   = "Message from MqttPublishSample Server";
        String broker       = "tcp://localhost:1883";
        String  userName    = " userName";
        String  password    =  "passWord";
        String clientId    =   MqttClient.generateClientId();
   
        MemoryPersistence persistence = new MemoryPersistence();

        try {
            final MqttClient sampleClient = new MqttClient(broker, clientId, persistence);
            MqttConnectOptions connOpts = new MqttConnectOptions();
            
            connOpts.setCleanSession(true);
            connOpts.setUserName(userName);  
            connOpts.setPassword(password.toCharArray());
            connOpts.setKeepAliveInterval(60000);
            
            System.out.println("Connecting to broker: "+broker);
            sampleClient.connect(connOpts);
            System.out.println("Connected");
            sampleClient.setCallback(new MqttCallback() { 
                    public void connectionLost(Throwable cause) { 
                     System.out.println("connectionLost-----------"); 
                    } 
                    public void deliveryComplete(IMqttDeliveryToken token) { 
                     System.out.println("deliveryComplete---------" + token.isComplete()); 
                    } 
                    public void messageArrived(String topic, MqttMessage arg1) 
                      throws Exception { 
                     //System.out.println("messageArrived----------"+topic+" arg "+arg1.toString());
//                     if(arg1.toString().contains("2")){
//
//                         MqttMessage message = new MqttMessage(content.getBytes());
//                            
//                            //sampleClient.publish(topic, message);
//                            //xulymassage()
//                     }
                    	
                    	
                    	
                    	switch(topic){
	                    	/*case TOPIC_HOUSE_REG:
	                    		System.out.println("-> register : " + arg1 );
	                    		try {
	                    			
               	                 			final Connection conn = DriverManager.getConnection(JDBC_URL);
               	                 			pst = conn.prepareStatement(SQL_INSERT);
               	                 			
               	                 			
	                    			} catch (SQLException e) {
	                    					//log.error("Could not connect to database. Exiting",e );
	                    					System.exit(1);
	                    			}
	                    		break;*/
                    			
                    		case TOPIC_HOUSE_REMOVE:
                    			System.out.println("-> remove house: " + arg1);
                    			break;
                    			
                    		case TOPIC_HOUSE_UPDATE:
                    			System.out.println("-> update house:" + arg1);
                    			break;
                    			
                    		case TOPIC_HOUSE_GET:
                    			System.out.println("-> get house:" + arg1);
                    			break;
                    		default:
                    			break;			
                    	}              	             
                    } 
                   });
            sampleClient.subscribe(TOPIC_HOUSE_REG);
            sampleClient.subscribe(TOPIC_HOUSE_REMOVE);
            sampleClient.subscribe(TOPIC_HOUSE_UPDATE);
            sampleClient.subscribe(TOPIC_HOUSE_GET);
        } 
        catch(MqttException me) {
            System.out.println("reason "+me.getReasonCode());
            System.out.println("msg "+me.getMessage());
            System.out.println("loc "+me.getLocalizedMessage());
            System.out.println("cause "+me.getCause());
            System.out.println("excep "+me);
            me.printStackTrace();
        }
    }
    //xulymassage(){
    //kiem tra massage
    //dangkiuser();
    //}
    
    
    
    
    /*--------TAO DATABASE VOI MYSQL -----------------*/
    public int dbOpen(String host, String user, String password){
        try
        {
          // create a java mysql database connection
          String myDriver = "org.gjt.mm.mysql.Driver";
          String JDBC_URL = "jdbc:mysql://localhost/DeviceMange";
          Class.forName(myDriver);
          Connection conn = DriverManager.getConnection(JDBC_URL, user, password);

          // your prepstatements goes here...
          
          
          System.err.println("Connect to db success! ");

          conn.close();
        }
        catch (Exception e)
        {
          System.err.println("Got an exception! ");
          System.err.println(e.getMessage());
          return -1;
        }
        return 0;
    }
}