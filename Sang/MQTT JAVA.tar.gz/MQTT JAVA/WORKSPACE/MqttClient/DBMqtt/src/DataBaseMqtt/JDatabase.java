package DataBaseMqtt;



import java.sql.*;


public class JDatabase {
	// JDBC driver name and database URL
	   static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";  
	   static final String DB_URL = "jdbc:mysql://localhost/DeviceMange";

	   //  Database credentials
	   static final String USER = "root";
	   static final String PASS = "";
	   public static void main(String[] args) {
	   Connection conn = null;
	   Statement stmt = null;
	   //PreparedStatement pst=null;
	   try{
	      //STEP 2: Register JDBC driver
	      Class.forName("com.mysql.jdbc.Driver");

	      //STEP 3: Open a connection
	      System.out.println("Connecting to database...");
	      conn = DriverManager.getConnection(DB_URL,USER,PASS);

//	      //STEP 4: Execute a query
//	      System.out.println("Creating statement...");
//	      stmt = conn.createStatement();
//	      String sql;
//	      sql = "SELECT id, first, last, age FROM Employees";
//	      ResultSet rs = stmt.executeQuery(sql);
//
//	      //STEP 5: Extract data from result set
//	      while(rs.next()){
//	         //Retrieve by column name
//	         int id  = rs.getInt("id");
//	         int age = rs.getInt("age");
//	         String first = rs.getString("first");
//	         String last = rs.getString("last");
//
//	         //Display values
//	         System.out.print("ID: " + id);
//	         System.out.print(", Age: " + age);
//	         System.out.print(", First: " + first);
//	         System.out.println(", Last: " + last);
//	      }
//	      //STEP 6: Clean-up environment
//	      rs.close();
	      
	    //STEP 4: Execute a query
	      System.out.println("Creating table in given database...");
	      stmt = conn.createStatement();
	      
	     /* String sql = "CREATE TABLE User " +
                  "(ID INTEGER not NULL, " +
                  " NameUser VARCHAR(255), " + 
                  " passWord BIGINT not NULL, " + 
                  " PRIMARY KEY ( ID ))"; 
	      
	      

	      stmt.executeUpdate(sql);
	      System.out.println("Created table in given database...");
	      
	      //STEP 4: Execute a query
	      System.out.println("Inserting records into the table...");
	      stmt = conn.createStatement();
	      int id =120;
	      String name="sang le thanh";
	      String pass="123456";
	      int age=24;
	      sql = "INSERT INTO Registration(id,first,last,age) VALUES (?,?,?,?) ";
	     pst= conn.prepareStatement(sql);
	     pst.setInt(1, id);
	     pst.setString(2, name);
	      pst.setString(3, pass);
	     pst.setInt(4, age);
	     pst.executeUpdate();
	     //note :  stmt.executeUpdate(sql);
	  
	     // sql = "INSERT INTO Registration " +
	                  // "VALUES(103, 'Sumit', 'Mittal', 28)";
	//stmt.executeUpdate(sql);
	      System.out.println("Inserted records into the table...");
	      sql ="UPDATE Registration SET age=200 WHERE id like 101";
	      stmt.executeUpdate(sql);
	      stmt.close();
	      conn.close();*/
	   }catch(SQLException se){
	      //Handle errors for JDBC
	      se.printStackTrace();
	   }catch(Exception e){
	      //Handle errors for Class.forName
	      e.printStackTrace();
	   }finally{
	      //finally block used to close resources
	      try{
	         if(stmt!=null)
	            stmt.close();
	      }catch(SQLException se2){
	      }// nothing we can do
	      try{
	         if(conn!=null)
	            conn.close();
	      }catch(SQLException se){
	         se.printStackTrace();
	      }//end finally try
	   }//end try
	   System.out.println("Goodbye!");
	}//end main
}







