package MqttClientGW;

import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.eclipse.paho.client.mqttv3.internal.wire.MqttPublish;
import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence;

public class SampleMqttClientGW {

	public static final String TOPIC_HOUSE_REG 		= "/house/register";
	public static final String TOPIC_HOUSE_UPDATE   = "/house/update";
	public static final String TOPIC_HOUSE_REMOVE   = "/house/remove";
	public static final String TOPIC_HOUSE_GET 		= "/house/get";
	
	public static void main(String[] args) {
		
		SampleMqttClientGW mqttGW = new SampleMqttClientGW();
		mqttGW.runGW();

	}
	
	 public SampleMqttClientGW(){
         
	    }
	    
	 public void runGW(){
	        String topic;
	        
	        final String content      = "Message from MqttPublishSample Server";
	        String broker       	  = "tcp://localhost:1883";
	        String  userName    	  = " userName";
	        String  password    	  =  "passWord";
	        String clientId    		  =   MqttClient.generateClientId();
	   
	        MemoryPersistence persistence = new MemoryPersistence();

	        try {
	            final MqttClient sampleClient = new MqttClient(broker, clientId, persistence);
	            MqttConnectOptions connOpts = new MqttConnectOptions();
	            System.out.println("Connecting to broker: "+broker);
	            sampleClient.connect(connOpts);
	            System.out.println("Connected");
	            sampleClient.setCallback(new MqttCallback() { 
	                    public void connectionLost(Throwable cause) { 
	                     System.out.println("connectionLost-----------"); 
	                    } 
	                    public void deliveryComplete(IMqttDeliveryToken token) { 
	                     System.out.println("deliveryComplete---------"+ token.isComplete()); 
	                    } 
	                    public void messageArrived(String topic, MqttMessage arg1) 
	                      throws Exception { 
	                    System.out.println("messageArrived----------"+topic+" arg "+arg1.toString());
	                    } 
	                   });
	            
	            sampleClient.publish(TOPIC_HOUSE_REG, "REGISTER_HOUSE".getBytes(),1,true);
	            sampleClient.publish(TOPIC_HOUSE_UPDATE, "TOPIC_HOUSE_UPDATE".getBytes(),1,true);
	            sampleClient.publish(TOPIC_HOUSE_REMOVE , "TOPIC_HOUSE_REMOVE ".getBytes(),1,true);
	            sampleClient.publish(TOPIC_HOUSE_GET, "TOPIC_HOUSE_GET".getBytes(),2,true);
	        } 
	        catch(MqttException me) {
	            System.out.println("reason "+me.getReasonCode());
	            System.out.println("msg "+me.getMessage());
	            System.out.println("loc "+me.getLocalizedMessage());
	            System.out.println("cause "+me.getCause());
	            System.out.println("excep "+me);
	            me.printStackTrace();
	        }
	    }
	 
	 
	 

}
