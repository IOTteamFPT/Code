# oedevguidevn - Open Embedded Development Guiding in Vietnamese
Vietnamese translation of development guides for open embedded 

Open Embedded is based on reference distribution Yocto Project
https://www.yoctoproject.org/

#Nội dung chính#
Tập hợp các hướng dẫn về việc phát triển OpenEmbedded (một phần của Yocto Project)
được dịch và thử nghiệm.

###Danh sách các tài liệu sẽ dịch
1. BitBake User Manual (phiên bản mới nhất là 1.8)
2. Yocto Project Linux Kernel Development Manual (Phiên bản mới nhất là 1.8)
3. Yocto Project Development Manual (Mới nhất là 1.8)
4. MQTT Protocol Version 3 revision 1
